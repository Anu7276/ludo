# 🎲 Ludo Online

A real-time multiplayer Ludo game for 2–6 players, built with React, Node.js, Express, and Socket.io. Players create or join a room with a short code, chat while they play, and race four pieces around the board — all in-memory, no database required.

## Stack

- **Frontend:** React 18 + Vite, plain CSS Modules (no UI framework)
- **Backend:** Node.js + Express + Socket.io
- **Storage:** In-memory (rooms and game state live in the server process; restart clears everything)

## Project structure

```
ludo-game/
├── frontend/          React app (Vite)
│   └── src/
│       ├── components/   Board, Chat, DiceRoller, PlayerPanel, GameOver
│       ├── pages/        HomePage, LobbyPage, GamePage
│       ├── services/     socket.js (Socket.io client)
│       └── utils/        boardLayout.js (board geometry, shared mental model with backend)
└── backend/           Express + Socket.io server
    ├── server.js         HTTP routes + all Socket.io event handlers
    ├── gameLogic.js       Core Ludo rules: dice, movement, captures, win detection
    └── roomManager.js     In-memory room/player bookkeeping
```

## Running locally

Open two terminals.

**Backend** (port 5000):
```bash
cd backend
npm install
npm start
```

**Frontend** (port 5173):
```bash
cd frontend
npm install
npm run dev
```

Then open `http://localhost:5173` in two or more browser tabs (or share your local network address with friends) to test multiplayer.

The frontend's Vite dev server proxies `/api` and `/socket.io` to `http://localhost:5000`, so no extra configuration is needed for local development. For a real deployment, set `VITE_BACKEND_URL` for the frontend build and update the CORS origins list in `backend/server.js`.

## How the board works

The board is modeled as a 56-cell ring on a 15×15 grid (rather than the commonly-cited "52 squares" — this board uses 14 cells per arm so the geometry comes out perfectly symmetric with no awkward corner cells). Each player's piece position is tracked as a small integer (`relativePos`):

- `-1` — sitting in the home base, not yet entered
- `0–54` — somewhere on the shared 56-cell ring, counted relative to that player's own starting square
- `55–59` — in that player's own 5-cell colored home column (private, can't be captured here)
- `60` — finished

This single number is all the server needs to know where a piece is and what moves are legal; the frontend (`boardLayout.js`) converts it to actual `[row, col]` grid coordinates for rendering, and both files are kept in sync on this scheme.

## Game rules implemented

- 2–6 players, each with 4 pieces
- Roll a 6 to bring a piece out of the home base
- Landing exactly on an opponent's piece sends it back to their home base, unless that cell is a safe cell (marked with a star, including every player's own start square)
- Rolling a 6 or capturing a piece grants a bonus turn; three consecutive sixes forfeits the bonus (standard safety rule against infinite turns)
- A piece must land exactly on the final cell to finish — no overshooting
- Players are ranked in the order they finish all 4 pieces; the game ends when everyone has finished (or effectively when only one player remains with pieces left to finish)
- If a player disconnects mid-game, their pieces are auto-retired so turns skip them cleanly

## What's intentionally out of scope (per the brief)

- No database — everything resets when the server restarts
- No deployment config (Docker/Cloud Run) — designed to be dropped in later without touching game logic
- No accounts/auth — players just pick a display name per session

## Possible next steps

- Swap `roomManager.js`'s in-memory store for Firestore (or any persistent store) without touching `gameLogic.js`
- Add a turn timer (UI hook is already in place in `PlayerPanel`, just needs a countdown)
- Spectator mode, game history/replay, sound effects

// gameLogic.js — Core Ludo rules and game state management
//
// Supports 4-player (56-cell ring, 15×15 grid) and 6-player (84-cell ring, 21×21 grid).
//
// 4-player relativePos reference:
//   -1    = home base   0-54  = main ring   55-59 = home column   60 = finished
//
// 6-player relativePos reference:
//   -1    = home base   0-82  = main ring   83-91 = home column   92 = finished

const PIECES_PER_PLAYER = 4;
const HOME_POSITION = -1;

// ── 4-player constants ──────────────────────────────────────────────────────
const BOARD_SIZE_4P        = 56;
const MAIN_RING_STEPS_4P   = 55;
const HOME_COLUMN_LENGTH_4P = 5;
const FINISH_4P            = MAIN_RING_STEPS_4P + HOME_COLUMN_LENGTH_4P; // 60
const PLAYER_START_4P      = [0, 14, 28, 42];
const SAFE_4P              = new Set([0, 8, 14, 22, 28, 36, 42, 50]);

// ── 6-player constants ──────────────────────────────────────────────────────
const BOARD_SIZE_6P        = 84;
const MAIN_RING_STEPS_6P   = 83;
const HOME_COLUMN_LENGTH_6P = 9;
const FINISH_6P            = MAIN_RING_STEPS_6P + HOME_COLUMN_LENGTH_6P; // 92
const PLAYER_START_6P      = [0, 14, 28, 42, 56, 70];
const SAFE_6P              = new Set([0, 7, 14, 21, 28, 35, 42, 49, 56, 63, 70, 77]);

// ── Select constants by player count ────────────────────────────────────────
function getConstants(playerCount) {
  if (playerCount >= 5) {
    return {
      BOARD_SIZE: BOARD_SIZE_6P,
      MAIN_RING_STEPS: MAIN_RING_STEPS_6P,
      HOME_COLUMN_LENGTH: HOME_COLUMN_LENGTH_6P,
      FINISH_RELATIVE_POS: FINISH_6P,
      PLAYER_START_POSITIONS: PLAYER_START_6P,
      SAFE_POSITIONS: SAFE_6P,
    };
  }
  return {
    BOARD_SIZE: BOARD_SIZE_4P,
    MAIN_RING_STEPS: MAIN_RING_STEPS_4P,
    HOME_COLUMN_LENGTH: HOME_COLUMN_LENGTH_4P,
    FINISH_RELATIVE_POS: FINISH_4P,
    PLAYER_START_POSITIONS: PLAYER_START_4P,
    SAFE_POSITIONS: SAFE_4P,
  };
}

// Legacy exports for backward compatibility (4-player defaults)
const BOARD_SIZE            = BOARD_SIZE_4P;
const MAIN_RING_STEPS       = MAIN_RING_STEPS_4P;
const HOME_COLUMN_LENGTH    = HOME_COLUMN_LENGTH_4P;
const FINISH_RELATIVE_POS   = FINISH_4P;
const PLAYER_START_POSITIONS = PLAYER_START_4P;
const SAFE_POSITIONS         = SAFE_4P;

function rollDice() {
  return Math.floor(Math.random() * 6) + 1;
}

// Convert player-relative position to absolute ring position (or special encoding
// for home column cells, which are exclusive to that player and never shared).
// Returns: -1 (home base), 0-N (absolute ring cell), or 1000+playerIndex*10+col (home column)
function relativeToAbsolute(playerIndex, relPos, C) {
  if (relPos < 0) return HOME_POSITION;
  if (relPos >= C.MAIN_RING_STEPS) {
    // In home column or finished
    const homeColIdx = relPos - C.MAIN_RING_STEPS;
    return 1000 + playerIndex * 10 + homeColIdx;
  }
  return (C.PLAYER_START_POSITIONS[playerIndex] + relPos) % C.BOARD_SIZE;
}

// Check if an absolute ring position is a safe cell
function isSafeRingCell(absolutePos, C) {
  return absolutePos >= 0 && absolutePos < C.BOARD_SIZE && C.SAFE_POSITIONS.has(absolutePos);
}

function initializeGameState(players) {
  const playerCount = players.length;
  const C = getConstants(playerCount);
  return {
    players: players.map((p, idx) => ({
      ...p,
      index: idx,
      pieces: Array.from({ length: PIECES_PER_PLAYER }, (_, i) => ({
        id: i,
        relativePos: HOME_POSITION,
        finished: false,
      })),
      piecesFinished: 0,
      rank: null,
    })),
    playerCount,
    currentTurnIndex: 0,
    diceResult: null,
    diceRolled: false,
    validMoves: [],
    moveHistory: [],
    status: 'in_progress',
    winners: [],
    consecutiveSixes: 0,
  };
}

// Get valid moves for a given player after a dice roll
function getValidMoves(gameState, playerId, diceResult) {
  const playerIdx = gameState.players.findIndex(p => p.id === playerId);
  if (playerIdx === -1) return [];

  const C = getConstants(gameState.playerCount || gameState.players.length);
  const player = gameState.players[playerIdx];
  const validMoves = [];

  for (const piece of player.pieces) {
    if (piece.finished) continue;
    const currentRel = piece.relativePos;

    // Piece in home base — needs a 6 to enter the ring
    if (currentRel === HOME_POSITION) {
      if (diceResult === 6) {
        const newRel = 0;
        const newAbs = relativeToAbsolute(playerIdx, newRel, C);
        validMoves.push({
          pieceId: piece.id,
          newRelPos: newRel,
          newAbsPos: newAbs,
          captures: getCaptures(gameState, playerIdx, newAbs, C),
          fromHome: true,
        });
      }
      continue;
    }

    // Piece already finished its journey
    if (currentRel >= C.FINISH_RELATIVE_POS) continue;

    const newRel = currentRel + diceResult;

    // Can't overshoot the finish — must land exactly
    if (newRel > C.FINISH_RELATIVE_POS) continue;

    const newAbs = relativeToAbsolute(playerIdx, newRel, C);

    // Only main-ring cells (< MAIN_RING_STEPS) can have captures; home column is private & safe
    const captures = newRel < C.MAIN_RING_STEPS
      ? getCaptures(gameState, playerIdx, newAbs, C)
      : [];

    validMoves.push({
      pieceId: piece.id,
      newRelPos: newRel,
      newAbsPos: newAbs,
      captures,
      fromHome: false,
    });
  }

  return validMoves;
}

// Returns opponent pieces that would be captured by landing on absolutePos
function getCaptures(gameState, attackerIdx, absolutePos, C) {
  // Home column cells (>= 1000) are private/safe — never capturable
  if (absolutePos >= 1000 || absolutePos < 0) return [];
  if (isSafeRingCell(absolutePos, C)) return [];

  const captures = [];
  for (const opponent of gameState.players) {
    if (opponent.index === attackerIdx) continue;
    for (const piece of opponent.pieces) {
      if (piece.finished) continue;
      const oppAbs = relativeToAbsolute(opponent.index, piece.relativePos, C);
      if (oppAbs === absolutePos) {
        captures.push({ playerId: opponent.id, pieceId: piece.id });
      }
    }
  }
  return captures;
}

// Apply a chosen move (assumes it was already validated against gameState.validMoves)
function applyMove(gameState, playerId, pieceId, diceResult) {
  const state = JSON.parse(JSON.stringify(gameState));
  const C = getConstants(state.playerCount || state.players.length);
  const playerIdx = state.players.findIndex(p => p.id === playerId);
  if (playerIdx === -1) return { state, error: 'Player not found' };

  const player = state.players[playerIdx];
  const piece = player.pieces.find(p => p.id === pieceId);
  if (!piece) return { state, error: 'Piece not found' };

  const validMove = state.validMoves.find(m => m.pieceId === pieceId);
  if (!validMove) return { state, error: 'Invalid move' };

  // Apply captures
  const capturedPieces = [];
  for (const cap of validMove.captures) {
    const oppPlayer = state.players.find(p => p.id === cap.playerId);
    const oppPiece = oppPlayer?.pieces.find(p => p.id === cap.pieceId);
    if (oppPiece) {
      oppPiece.relativePos = HOME_POSITION;
      capturedPieces.push({ playerId: cap.playerId, pieceId: cap.pieceId });
    }
  }

  // Move the piece
  piece.relativePos = validMove.newRelPos;

  const justFinished = validMove.newRelPos === C.FINISH_RELATIVE_POS;
  if (justFinished) {
    piece.finished = true;
    player.piecesFinished += 1;
    if (player.piecesFinished === PIECES_PER_PLAYER) {
      state.winners.push(playerId);
      player.rank = state.winners.length;
    }
  }

  state.moveHistory.push({
    playerId,
    pieceId,
    diceResult,
    toPos: validMove.newRelPos,
    captures: capturedPieces,
    timestamp: Date.now(),
  });

  const finishedPlayers = state.players.filter(p => p.piecesFinished === PIECES_PER_PLAYER);
  if (finishedPlayers.length === state.players.length) {
    state.status = 'finished';
  }

  // Bonus turn: rolling a 6 or capturing a piece grants another roll
  let bonusTurn = diceResult === 6 || capturedPieces.length > 0;

  if (bonusTurn && state.status === 'in_progress') {
    if (diceResult === 6) {
      state.consecutiveSixes += 1;
      if (state.consecutiveSixes >= 3) {
        // Three sixes in a row forfeits the bonus turn (standard safety rule)
        state.consecutiveSixes = 0;
        state.currentTurnIndex = nextActivePlayerIndex(state, playerIdx);
        state.diceRolled = false;
        state.diceResult = null;
        state.validMoves = [];
        return { state, capturedPieces, justFinished, bonusTurn: false };
      }
    } else {
      state.consecutiveSixes = 0;
    }
  } else {
    state.consecutiveSixes = 0;
    state.currentTurnIndex = nextActivePlayerIndex(state, playerIdx);
  }

  state.diceRolled = false;
  state.diceResult = null;
  state.validMoves = [];

  return { state, capturedPieces, justFinished, bonusTurn };
}

// Find the next player index who still has unfinished pieces
function nextActivePlayerIndex(state, fromIdx) {
  let idx = (fromIdx + 1) % state.players.length;
  let attempts = 0;
  while (
    state.players[idx].piecesFinished === PIECES_PER_PLAYER &&
    attempts < state.players.length
  ) {
    idx = (idx + 1) % state.players.length;
    attempts++;
  }
  return idx;
}

// Roll dice for a player and compute their valid moves
function processDiceRoll(gameState, playerId) {
  const state = JSON.parse(JSON.stringify(gameState));
  const playerIdx = state.players.findIndex(p => p.id === playerId);

  if (playerIdx !== state.currentTurnIndex) {
    return { state, error: 'Not your turn' };
  }

  const diceResult = rollDice();
  state.diceResult = diceResult;
  state.diceRolled = true;

  const validMoves = getValidMoves(state, playerId, diceResult);
  state.validMoves = validMoves;

  if (validMoves.length === 0) {
    // No legal moves — turn passes automatically
    state.diceRolled = false;
    state.currentTurnIndex = nextActivePlayerIndex(state, playerIdx);
    state.consecutiveSixes = 0;
    return { state, diceResult, validMoves: [], autoAdvanced: true };
  }

  return { state, diceResult, validMoves };
}

// Expose board constants for use in routes/socket handlers
function getBoardConstants(playerCount) {
  return getConstants(playerCount);
}

module.exports = {
  initializeGameState,
  processDiceRoll,
  applyMove,
  getValidMoves,
  relativeToAbsolute,
  getBoardConstants,
  // 4-player defaults (backward compatible)
  PLAYER_START_POSITIONS,
  SAFE_POSITIONS,
  BOARD_SIZE,
  MAIN_RING_STEPS,
  HOME_COLUMN_LENGTH,
  FINISH_RELATIVE_POS,
  HOME_POSITION,
  // 6-player constants
  BOARD_SIZE_6P,
  MAIN_RING_STEPS_6P,
  HOME_COLUMN_LENGTH_6P,
  FINISH_6P,
  PLAYER_START_6P,
  SAFE_6P,
};

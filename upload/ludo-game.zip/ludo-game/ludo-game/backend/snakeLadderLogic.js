// snakeLadderLogic.js — Core Snake & Ladder rules and game state management
//
// Function shapes intentionally mirror backend/gameLogic.js (initializeGameState,
// processDiceRoll, applyMove, checkWinner-equivalent) so server.js can call either
// module interchangeably based on room.gameType, without branching logic deep
// inside each handler.
//
// Board: 100 cells (1-100), single piece per player (no "pieces array" like Ludo).
// position: 0 = off board (not yet entered), 1-100 = on board, 100 = finished.
//
// Entry rule (documented per the spec's ask): ANY roll lets a piece enter the
// board from position 0 — there is no "must roll a 6" requirement like Ludo.
// This matches the most common real-world Snake & Ladder house rule and keeps
// the early game moving for a simpler, more casual game mode than Ludo.

const BOARD_SIZE = 100;

// Classic Snake & Ladder layout. Keys = special cell, values = destination.
const LADDERS = { 2: 38, 7: 14, 8: 31, 15: 26, 21: 42, 28: 84, 36: 44, 51: 67, 71: 91, 78: 98 };
const SNAKES = { 16: 6, 46: 25, 49: 11, 62: 19, 64: 60, 74: 53, 89: 68, 92: 88, 95: 75, 99: 58 };

function rollDice() {
  return Math.floor(Math.random() * 6) + 1;
}

function createInitialState(players) {
  return {
    players: players.map((p, idx) => ({
      ...p,
      index: idx,
      position: 0,       // 0 = off board, 1-100 = on board
      finished: false,
    })),
    currentTurnIndex: 0,
    diceResult: null,
    diceRolled: false,
    moveHistory: [],
    status: 'in_progress',
    winners: [],
    consecutiveSixes: 0,
  };
}

// Roll dice for the current player. Snake & Ladder has no "valid moves"
// selection step (single piece, always movable once rolled) — server.js is
// expected to immediately follow this with applyMove in the same handler.
function processDiceRoll(state, playerId) {
  const newState = JSON.parse(JSON.stringify(state));
  const playerIdx = newState.players.findIndex(p => p.id === playerId);

  if (playerIdx !== newState.currentTurnIndex) {
    return { state: newState, error: 'Not your turn' };
  }
  if (newState.players[playerIdx].finished) {
    return { state: newState, error: 'You have already finished' };
  }

  const diceResult = rollDice();
  newState.diceResult = diceResult;
  newState.diceRolled = true;

  return { state: newState, diceResult };
}

// Apply the move implied by the just-rolled dice (always exactly one legal
// move in Snake & Ladder, so no pieceId/validMoves concept is needed).
function applyMove(state, playerId) {
  const newState = JSON.parse(JSON.stringify(state));
  const playerIdx = newState.players.findIndex(p => p.id === playerId);
  if (playerIdx === -1) return { state: newState, error: 'Player not found' };

  const player = newState.players[playerIdx];
  if (!newState.diceRolled || newState.diceResult == null) {
    return { state: newState, error: 'Roll dice first' };
  }

  const diceResult = newState.diceResult;
  const oldPosition = player.position;
  let newPosition = oldPosition + diceResult;

  // Overshoot rule: must land exactly on 100, otherwise the piece doesn't move.
  if (newPosition > BOARD_SIZE) {
    newPosition = oldPosition; // no movement this turn
  }

  let hitSnake = null;
  let hitLadder = null;

  if (newPosition !== oldPosition) {
    if (SNAKES[newPosition]) {
      hitSnake = { from: newPosition, to: SNAKES[newPosition] };
      newPosition = SNAKES[newPosition];
    } else if (LADDERS[newPosition]) {
      hitLadder = { from: newPosition, to: LADDERS[newPosition] };
      newPosition = LADDERS[newPosition];
    }
  }

  player.position = newPosition;

  const justFinished = newPosition === BOARD_SIZE;
  if (justFinished) {
    player.finished = true;
    if (!newState.winners.includes(playerId)) {
      newState.winners.push(playerId);
    }
  }

  newState.moveHistory.push({
    playerId,
    diceResult,
    fromPos: oldPosition,
    toPos: newPosition,
    hitSnake,
    hitLadder,
    timestamp: Date.now(),
  });

  // Game ends when only one (or zero) unfinished players remain
  const unfinished = newState.players.filter(p => !p.finished);
  if (unfinished.length <= 1) {
    newState.status = 'finished';
    // If exactly one remains, rank them last automatically for a clean GameOver list
    if (unfinished.length === 1 && !newState.winners.includes(unfinished[0].id)) {
      newState.winners.push(unfinished[0].id);
    }
  }

  // Bonus turn on rolling a 6, same safety rule as Ludo (3 consecutive sixes forfeits)
  let bonusTurn = diceResult === 6;

  if (bonusTurn && newState.status === 'in_progress' && !justFinished) {
    newState.consecutiveSixes += 1;
    if (newState.consecutiveSixes >= 3) {
      newState.consecutiveSixes = 0;
      newState.currentTurnIndex = nextActivePlayerIndex(newState, playerIdx);
      bonusTurn = false;
    }
    // else: same player goes again, currentTurnIndex unchanged
  } else {
    newState.consecutiveSixes = 0;
    if (newState.status === 'in_progress') {
      newState.currentTurnIndex = nextActivePlayerIndex(newState, playerIdx);
    }
  }

  newState.diceRolled = false;
  newState.diceResult = null;

  // Don't grant a bonus turn if the game ended this move (player just won)
  if (newState.status === 'finished') {
    bonusTurn = false;
  }

  return { state: newState, newPosition, hitSnake, hitLadder, justFinished, bonusTurn };
}

function nextActivePlayerIndex(state, fromIdx) {
  let idx = (fromIdx + 1) % state.players.length;
  let attempts = 0;
  while (state.players[idx].finished && attempts < state.players.length) {
    idx = (idx + 1) % state.players.length;
    attempts++;
  }
  return idx;
}

// Returns finished players in the order they finished (matches Ludo's
// state.winners / rank pattern so GameOver.jsx can be reused as-is).
function checkWinner(state) {
  return state.winners
    .map(id => state.players.find(p => p.id === id))
    .filter(Boolean);
}

module.exports = {
  createInitialState,
  rollDice,
  processDiceRoll,
  applyMove,
  checkWinner,
  nextActivePlayerIndex,
  LADDERS,
  SNAKES,
  BOARD_SIZE,
};

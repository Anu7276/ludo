// roomManager.js — In-memory room and player management

const { initializeGameState } = require('./gameLogic');
const { createInitialState: createSnakeLadderState } = require('./snakeLadderLogic');

const PLAYER_COLORS = ['red', 'yellow', 'green', 'blue', 'purple', 'cyan'];
const COLOR_HEX = {
  red: '#EF4444',
  yellow: '#FBBF24',
  green: '#22C55E',
  blue: '#3B82F6',
  purple: '#A855F7',
  cyan: '#06B6D4',
};

// In-memory store
const rooms = {};

function generateRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do {
    code = Array.from({ length: 5 }, () =>
      chars[Math.floor(Math.random() * chars.length)]
    ).join('');
  } while (rooms[code]);
  return code;
}

function createRoom(roomName, maxPlayers, playerName, socketId, gameType = 'ludo', avatar = null) {
  const roomCode = generateRoomCode();
  const playerId = generatePlayerId();

  const player = {
    id: playerId,
    name: playerName,
    color: PLAYER_COLORS[0],
    colorHex: COLOR_HEX[PLAYER_COLORS[0]],
    avatar: avatar || null,
    socketId,
    ready: false,
    isHost: true,
    joinedAt: Date.now(),
  };

  rooms[roomCode] = {
    roomCode,
    roomName: roomName || `${playerName}'s Game`,
    gameType: gameType === 'snake-ladder' ? 'snake-ladder' : 'ludo', // default to 'ludo', backward compatible
    maxPlayers: Math.min(Math.max(parseInt(maxPlayers) || 4, 2), 6),
    players: [player],
    gameState: null,
    createdAt: Date.now(),
    status: 'waiting', // waiting | in_progress | finished
    messages: [],
  };

  return { roomCode, player, room: rooms[roomCode] };
}

function joinRoom(roomCode, playerName, socketId, avatar = null) {
  const room = rooms[roomCode];
  if (!room) return { error: 'Room not found' };
  if (room.status !== 'waiting') return { error: 'Game already in progress' };
  if (room.players.length >= room.maxPlayers) return { error: 'Room is full' };

  // Check for duplicate name
  const existing = room.players.find(
    p => p.name.toLowerCase() === playerName.toLowerCase()
  );
  if (existing) {
    // If same socket reconnecting, allow
    if (existing.socketId === socketId) return { player: existing, room };
    return { error: 'Name already taken in this room' };
  }

  const colorIndex = room.players.length;
  const playerId = generatePlayerId();

  const player = {
    id: playerId,
    name: playerName,
    color: PLAYER_COLORS[colorIndex],
    colorHex: COLOR_HEX[PLAYER_COLORS[colorIndex]],
    avatar: avatar || null,
    socketId,
    ready: false,
    isHost: false,
    joinedAt: Date.now(),
  };

  room.players.push(player);
  return { player, room };
}

function leaveRoom(roomCode, playerId) {
  const room = rooms[roomCode];
  if (!room) return { error: 'Room not found' };

  const playerIndex = room.players.findIndex(p => p.id === playerId);
  if (playerIndex === -1) return { error: 'Player not in room' };

  const player = room.players[playerIndex];
  room.players.splice(playerIndex, 1);

  // Reassign host if needed
  if (player.isHost && room.players.length > 0) {
    room.players[0].isHost = true;
  }

  // Clean up empty rooms
  if (room.players.length === 0) {
    delete rooms[roomCode];
    return { deleted: true, player };
  }

  return { room, player };
}

function startGame(roomCode) {
  const room = rooms[roomCode];
  if (!room) return { error: 'Room not found' };
  if (room.players.length < 2) return { error: 'Need at least 2 players' };
  if (room.status !== 'waiting') return { error: 'Game already started' };

  // Initialize game state with player data
  const gamePlayers = room.players.map(p => ({
    id: p.id,
    name: p.name,
    color: p.color,
    colorHex: p.colorHex,
    avatar: p.avatar || null,
  }));

  room.gameState = room.gameType === 'snake-ladder'
    ? createSnakeLadderState(gamePlayers)
    : initializeGameState(gamePlayers);
  room.status = 'in_progress';

  return { room, gameState: room.gameState };
}

function getRoomByCode(roomCode) {
  return rooms[roomCode] || null;
}

function listAvailableRooms() {
  return Object.values(rooms)
    .filter(r => r.status === 'waiting')
    .map(r => ({
      roomCode: r.roomCode,
      roomName: r.roomName,
      gameType: r.gameType || 'ludo',
      playerCount: r.players.length,
      maxPlayers: r.maxPlayers,
      players: r.players.map(p => ({ name: p.name, color: p.color, avatar: p.avatar || null })),
      createdAt: r.createdAt,
    }))
    .sort((a, b) => b.createdAt - a.createdAt);
}

function findPlayerBySocket(socketId) {
  for (const room of Object.values(rooms)) {
    const player = room.players.find(p => p.socketId === socketId);
    if (player) return { player, room };
  }
  return null;
}

function updatePlayerSocket(roomCode, playerId, newSocketId) {
  const room = rooms[roomCode];
  if (!room) return;
  const player = room.players.find(p => p.id === playerId);
  if (player) player.socketId = newSocketId;
}

function generatePlayerId() {
  return 'p_' + Math.random().toString(36).substr(2, 9);
}

function addMessage(roomCode, playerName, message, type = 'chat') {
  const room = rooms[roomCode];
  if (!room) return null;
  const msg = {
    id: Date.now() + Math.random(),
    playerName,
    message,
    type,
    timestamp: Date.now(),
  };
  room.messages.push(msg);
  // Keep only last 200 messages
  if (room.messages.length > 200) room.messages.shift();
  return msg;
}

// ─── Groups (friends play) ──────────────────────────────────────────────────
// TODO: move to persistent DB later. This is purely in-memory and session-scoped:
// a group (and its membership) only exists while the server process is running,
// and members are tracked by socketId so "online" status resets on every
// restart/disconnect. There is no chat history or persistence across sessions.

const groups = {};

function generateGroupCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do {
    code = 'G' + Array.from({ length: 4 }, () =>
      chars[Math.floor(Math.random() * chars.length)]
    ).join('');
  } while (groups[code]);
  return code;
}

function createGroup(groupName, creatorName, socketId) {
  const groupCode = generateGroupCode();
  const memberId = generatePlayerId();

  const member = {
    id: memberId,
    name: creatorName,
    socketId,
    isCreator: true,
    joinedAt: Date.now(),
  };

  groups[groupCode] = {
    groupCode,
    groupName: groupName || `${creatorName}'s Group`,
    members: [member],
    createdBy: memberId,
    createdAt: Date.now(),
  };

  return { groupCode, member, group: groups[groupCode] };
}

function joinGroup(groupCode, playerName, socketId) {
  const group = groups[groupCode];
  if (!group) return { error: 'Group not found' };

  const existing = group.members.find(
    m => m.name.toLowerCase() === playerName.toLowerCase()
  );
  if (existing) {
    // Reconnecting under the same name — just refresh their socketId so they
    // show as online again.
    existing.socketId = socketId;
    return { member: existing, group };
  }

  const member = {
    id: generatePlayerId(),
    name: playerName,
    socketId,
    isCreator: false,
    joinedAt: Date.now(),
  };
  group.members.push(member);
  return { member, group };
}

function getGroup(groupCode) {
  return groups[groupCode] || null;
}

function listGroupMembers(groupCode) {
  const group = groups[groupCode];
  return group ? group.members : [];
}

// Mark a group member offline/online by socketId (used so invite_to_room only
// notifies members who currently have an active connection).
function updateGroupMemberSocket(groupCode, memberId, newSocketId) {
  const group = groups[groupCode];
  if (!group) return;
  const member = group.members.find(m => m.id === memberId);
  if (member) member.socketId = newSocketId;
}

module.exports = {
  createRoom,
  joinRoom,
  leaveRoom,
  startGame,
  getRoomByCode,
  listAvailableRooms,
  findPlayerBySocket,
  updatePlayerSocket,
  addMessage,
  rooms,
  // Groups (Part C)
  createGroup,
  joinGroup,
  getGroup,
  listGroupMembers,
  updateGroupMemberSocket,
  groups,
};

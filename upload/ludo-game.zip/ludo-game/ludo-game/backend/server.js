// server.js — Express + Socket.io server

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const {
  createRoom,
  joinRoom,
  leaveRoom,
  startGame,
  getRoomByCode,
  listAvailableRooms,
  addMessage,
  rooms,
  createGroup,
  joinGroup,
  getGroup,
  updateGroupMemberSocket,
} = require('./roomManager');

const { processDiceRoll, applyMove } = require('./gameLogic');
const snakeLadderLogic = require('./snakeLadderLogic');

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: ['http://localhost:5173', 'http://localhost:3000', 'http://localhost:5174'],
    methods: ['GET', 'POST'],
    credentials: true,
  },
});

app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:3000', 'http://localhost:5174'],
  credentials: true,
}));
app.use(express.json());

// ─── REST API ──────────────────────────────────────────────────────────────

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', rooms: Object.keys(rooms).length, timestamp: Date.now() });
});

app.get('/api/rooms', (req, res) => {
  res.json(listAvailableRooms());
});

app.get('/api/room/:roomCode', (req, res) => {
  const room = getRoomByCode(req.params.roomCode.toUpperCase());
  if (!room) return res.status(404).json({ error: 'Room not found' });
  const { gameState, ...safeRoom } = room;
  res.json({ ...safeRoom, hasGame: !!gameState });
});

// ─── Socket.io ─────────────────────────────────────────────────────────────

io.on('connection', (socket) => {
  console.log(`[+] Socket connected: ${socket.id}`);

  // ── CREATE ROOM ──────────────────────────────────────────────────────────
  socket.on('create_room', ({ roomName, maxPlayers, playerName, gameType, avatar }) => {
    if (!playerName?.trim()) {
      return socket.emit('error', { message: 'Player name required' });
    }

    const result = createRoom(roomName, maxPlayers, playerName.trim(), socket.id, gameType, avatar);
    socket.join(result.roomCode);

    // Store context on socket
    socket.data.roomCode = result.roomCode;
    socket.data.playerId = result.player.id;
    socket.data.playerName = result.player.name;

    socket.emit('room_created', {
      roomCode: result.roomCode,
      player: result.player,
      room: sanitizeRoom(result.room),
    });

    console.log(`[Room] Created: ${result.roomCode} (${result.room.gameType}) by ${playerName}`);
  });

  // ── JOIN ROOM ────────────────────────────────────────────────────────────
  socket.on('join_room', ({ roomCode, playerName, avatar }) => {
    if (!playerName?.trim() || !roomCode) {
      return socket.emit('error', { message: 'Room code and player name required' });
    }

    const code = roomCode.trim().toUpperCase();
    const result = joinRoom(code, playerName.trim(), socket.id, avatar);

    if (result.error) {
      return socket.emit('join_error', { message: result.error });
    }

    socket.join(code);
    socket.data.roomCode = code;
    socket.data.playerId = result.player.id;
    socket.data.playerName = result.player.name;

    socket.emit('room_joined', {
      roomCode: code,
      player: result.player,
      room: sanitizeRoom(result.room),
    });

    // Notify other players
    socket.to(code).emit('player_joined', {
      player: result.player,
      players: result.room.players,
    });

    // System message
    const msg = addMessage(code, 'System', `${playerName} joined the game`, 'system');
    io.to(code).emit('message_received', msg);

    console.log(`[Room] ${playerName} joined: ${code}`);
  });

  // ── LEAVE ROOM ───────────────────────────────────────────────────────────
  socket.on('leave_room', ({ roomCode, playerId }) => {
    handleLeave(socket, roomCode, playerId);
  });

  // ── START GAME ───────────────────────────────────────────────────────────
  socket.on('start_game', ({ roomCode }) => {
    const room = getRoomByCode(roomCode);
    if (!room) return socket.emit('error', { message: 'Room not found' });

    const player = room.players.find(p => p.id === socket.data.playerId);
    if (!player?.isHost) {
      return socket.emit('error', { message: 'Only the host can start the game' });
    }

    const result = startGame(roomCode);
    if (result.error) {
      return socket.emit('error', { message: result.error });
    }

    io.to(roomCode).emit('game_started', {
      gameState: result.gameState,
      players: room.players,
    });

    const msg = addMessage(roomCode, 'System', 'Game started! Good luck!', 'system');
    io.to(roomCode).emit('message_received', msg);

    console.log(`[Game] Started in room: ${roomCode}`);
  });

  // ── ROLL DICE ────────────────────────────────────────────────────────────
  socket.on('roll_dice', ({ roomCode }) => {
    const room = getRoomByCode(roomCode);
    if (!room || room.status !== 'in_progress') return;

    const playerId = socket.data.playerId;
    const currentPlayer = room.gameState.players[room.gameState.currentTurnIndex];

    if (currentPlayer.id !== playerId) {
      return socket.emit('error', { message: 'Not your turn' });
    }

    if (room.gameState.diceRolled) {
      return socket.emit('error', { message: 'Dice already rolled, pick a piece' });
    }

    if (room.gameType === 'snake-ladder') {
      // Snake & Ladder: single piece, no "valid moves" selection step — roll
      // and move happen together in this one handler (see Part B2 spec).
      const rollResult = snakeLadderLogic.processDiceRoll(room.gameState, playerId);
      if (rollResult.error) return socket.emit('error', { message: rollResult.error });
      room.gameState = rollResult.state;

      io.to(roomCode).emit('dice_rolled', {
        playerId,
        diceResult: rollResult.diceResult,
        gameState: room.gameState,
      });

      const moveResult = snakeLadderLogic.applyMove(room.gameState, playerId);
      if (moveResult.error) return socket.emit('error', { message: moveResult.error });
      room.gameState = moveResult.state;

      if (moveResult.hitSnake) {
        const msg = addMessage(roomCode, 'System',
          `${currentPlayer.name} hit a snake! Down to ${moveResult.hitSnake.to} 🐍`, 'system');
        io.to(roomCode).emit('message_received', msg);
      }
      if (moveResult.hitLadder) {
        const msg = addMessage(roomCode, 'System',
          `${currentPlayer.name} climbed a ladder to ${moveResult.hitLadder.to}! 🪜`, 'system');
        io.to(roomCode).emit('message_received', msg);
      }
      if (moveResult.justFinished) {
        const msg = addMessage(roomCode, 'System',
          `🏆 ${currentPlayer.name} reached 100!`, 'system');
        io.to(roomCode).emit('message_received', msg);
      }

      io.to(roomCode).emit('piece_moved', {
        playerId,
        newPosition: moveResult.newPosition,
        hitSnake: moveResult.hitSnake,
        hitLadder: moveResult.hitLadder,
        justFinished: moveResult.justFinished,
        bonusTurn: moveResult.bonusTurn,
        gameState: room.gameState,
      });

      if (room.gameState.status === 'finished') {
        room.status = 'finished';
        const winners = snakeLadderLogic.checkWinner(room.gameState);
        io.to(roomCode).emit('game_over', { winners, gameState: room.gameState });
        const msg = addMessage(roomCode, 'System',
          `Game Over! ${winners[0]?.name} wins! 🎊`, 'system');
        io.to(roomCode).emit('message_received', msg);
      }

      return;
    }

    // Ludo (default/unchanged path)
    const result = processDiceRoll(room.gameState, playerId);
    if (result.error) return socket.emit('error', { message: result.error });

    room.gameState = result.state;

    io.to(roomCode).emit('dice_rolled', {
      playerId,
      diceResult: result.diceResult,
      validMoves: result.validMoves,
      autoAdvanced: result.autoAdvanced || false,
      gameState: room.gameState,
    });

    if (result.autoAdvanced) {
      const rollingPlayerName = currentPlayer.name;
      const nextPlayer = room.gameState.players[room.gameState.currentTurnIndex];
      const msg = addMessage(roomCode, 'System', `${rollingPlayerName} rolled ${result.diceResult} — no valid moves. ${nextPlayer.name}'s turn!`, 'system');
      io.to(roomCode).emit('message_received', msg);
    }
  });

  // ── MOVE PIECE ───────────────────────────────────────────────────────────
  // Ludo only — Snake & Ladder auto-moves inside the roll_dice handler above
  // since it has no piece-selection step (single piece per player).
  socket.on('move_piece', ({ roomCode, pieceId }) => {
    const room = getRoomByCode(roomCode);
    if (!room || room.status !== 'in_progress') return;
    if (room.gameType === 'snake-ladder') {
      return socket.emit('error', { message: 'Snake & Ladder moves automatically after rolling' });
    }

    const playerId = socket.data.playerId;
    const currentPlayer = room.gameState.players[room.gameState.currentTurnIndex];

    if (currentPlayer.id !== playerId) {
      return socket.emit('error', { message: 'Not your turn' });
    }

    if (!room.gameState.diceRolled) {
      return socket.emit('error', { message: 'Roll dice first' });
    }

    const isValidMove = room.gameState.validMoves.some(
      m => m.pieceId === parseInt(pieceId)
    );
    if (!isValidMove) {
      return socket.emit('error', { message: 'This piece cannot move with that roll' });
    }

    const result = applyMove(room.gameState, playerId, parseInt(pieceId), room.gameState.diceResult);
    if (result.error) return socket.emit('error', { message: result.error });

    room.gameState = result.state;

    // Capture notifications
    if (result.capturedPieces?.length > 0) {
      for (const cap of result.capturedPieces) {
        const capPlayer = room.gameState.players.find(p => p.id === cap.playerId);
        const attPlayer = room.gameState.players.find(p => p.id === playerId);
        const msg = addMessage(roomCode, 'System',
          `${attPlayer?.name} captured ${capPlayer?.name}'s piece! 🎯`, 'system');
        io.to(roomCode).emit('message_received', msg);
      }
    }

    // Piece finished notification
    if (result.justFinished) {
      const player = room.gameState.players.find(p => p.id === playerId);
      const msg = addMessage(roomCode, 'System',
        `${player?.name} got a piece home! 🏆`, 'system');
      io.to(roomCode).emit('message_received', msg);
    }

    // Winner notification
    if (room.gameState.winners.includes(playerId)) {
      const player = room.gameState.players.find(p => p.id === playerId);
      const msg = addMessage(roomCode, 'System',
        `🎉 ${player?.name} finished all pieces! Rank #${player?.rank}`, 'system');
      io.to(roomCode).emit('message_received', msg);
    }

    io.to(roomCode).emit('piece_moved', {
      playerId,
      pieceId: parseInt(pieceId),
      capturedPieces: result.capturedPieces || [],
      bonusTurn: result.bonusTurn,
      gameState: room.gameState,
    });

    // Game over
    if (room.gameState.status === 'finished') {
      room.status = 'finished';
      const winners = room.gameState.players
        .filter(p => p.rank)
        .sort((a, b) => a.rank - b.rank);
      io.to(roomCode).emit('game_over', { winners, gameState: room.gameState });
      const msg = addMessage(roomCode, 'System',
        `Game Over! ${winners[0]?.name} wins! 🎊`, 'system');
      io.to(roomCode).emit('message_received', msg);
    }
  });

  // ── CHAT MESSAGE ─────────────────────────────────────────────────────────
  socket.on('send_message', ({ roomCode, message }) => {
    if (!message?.trim()) return;
    const playerName = socket.data.playerName;
    if (!playerName) return;

    const msg = addMessage(roomCode, playerName, message.trim(), 'chat');
    if (msg) {
      io.to(roomCode).emit('message_received', msg);
    }
  });

  // ── PLAY AGAIN ───────────────────────────────────────────────────────────
  socket.on('play_again', ({ roomCode }) => {
    const room = getRoomByCode(roomCode);
    if (!room) return;

    const player = room.players.find(p => p.id === socket.data.playerId);
    if (!player?.isHost) return;

    room.status = 'waiting';
    room.gameState = null;
    room.messages = [];

    io.to(roomCode).emit('lobby_reset', {
      room: sanitizeRoom(room),
    });
  });

  // ── GROUPS (friends play) ────────────────────────────────────────────────
  socket.on('create_group', ({ groupName, playerName }) => {
    if (!playerName?.trim()) {
      return socket.emit('error', { message: 'Player name required' });
    }
    const result = createGroup(groupName, playerName.trim(), socket.id);
    socket.data.groupCode = result.groupCode;
    socket.data.groupMemberId = result.member.id;

    socket.emit('group_created', {
      groupCode: result.groupCode,
      member: result.member,
      group: result.group,
    });
    console.log(`[Group] Created: ${result.groupCode} by ${playerName}`);
  });

  socket.on('join_group', ({ groupCode, playerName }) => {
    if (!playerName?.trim() || !groupCode) {
      return socket.emit('error', { message: 'Group code and player name required' });
    }
    const code = groupCode.trim().toUpperCase();
    const result = joinGroup(code, playerName.trim(), socket.id);
    if (result.error) {
      return socket.emit('error', { message: result.error });
    }
    socket.data.groupCode = code;
    socket.data.groupMemberId = result.member.id;

    socket.emit('group_joined', { groupCode: code, member: result.member, group: result.group });
    // Notify other online members someone joined
    for (const m of result.group.members) {
      if (m.id !== result.member.id && m.socketId) {
        io.to(m.socketId).emit('group_member_joined', { member: result.member, group: result.group });
      }
    }
    console.log(`[Group] ${playerName} joined: ${code}`);
  });

  socket.on('get_group', ({ groupCode }) => {
    const group = getGroup(groupCode?.trim().toUpperCase());
    if (!group) return socket.emit('error', { message: 'Group not found' });
    socket.emit('group_info', { group });
  });

  socket.on('invite_to_room', ({ groupCode, roomCode }) => {
    const group = getGroup(groupCode?.trim().toUpperCase());
    if (!group) return socket.emit('error', { message: 'Group not found' });
    const room = getRoomByCode(roomCode);
    if (!room) return socket.emit('error', { message: 'Room not found' });

    const inviterId = socket.data.playerId || socket.data.groupMemberId;
    const inviterName = socket.data.playerName ||
      group.members.find(m => m.id === socket.data.groupMemberId)?.name || 'Someone';

    let invitedCount = 0;
    for (const member of group.members) {
      // Don't invite the inviter to their own room, and only invite members
      // who currently have a live connection (tracked via socketId).
      if (member.socketId && member.socketId !== socket.id) {
        io.to(member.socketId).emit('room_invite', {
          roomCode,
          roomName: room.roomName,
          gameType: room.gameType,
          invitedBy: inviterName,
          groupCode: group.groupCode,
        });
        invitedCount++;
      }
    }

    socket.emit('invite_sent', { roomCode, invitedCount });
    console.log(`[Group] ${inviterName} invited ${invitedCount} group member(s) to room ${roomCode}`);
  });

  // ── REJOIN ROOM (reconnect) ──────────────────────────────────────────────
  // Lets a client that already has a roomCode + playerId (kept in component
  // state / sessionStorage on the frontend) resume their seat after a socket
  // reconnect, instead of being treated as a brand-new join.
  socket.on('rejoin_room', ({ roomCode, playerId }) => {
    const room = getRoomByCode(roomCode);
    if (!room) return socket.emit('error', { message: 'Room no longer exists' });

    const player = room.players.find(p => p.id === playerId);
    if (!player) return socket.emit('error', { message: 'You are not a member of this room anymore' });

    // Re-bind this socket to the existing player record
    player.socketId = socket.id;
    delete player.disconnectedAt;
    socket.join(roomCode);
    socket.data.roomCode = roomCode;
    socket.data.playerId = player.id;
    socket.data.playerName = player.name;

    // Also refresh their socketId in any group they belong to, so invites
    // keep reaching them after a reconnect.
    if (socket.data.groupCode && socket.data.groupMemberId) {
      updateGroupMemberSocket(socket.data.groupCode, socket.data.groupMemberId, socket.id);
    }

    socket.emit('room_rejoined', {
      roomCode,
      player,
      room: sanitizeRoom(room),
      gameState: room.gameState,
    });
    console.log(`[Room] ${player.name} rejoined: ${roomCode}`);
  });

  // ── DISCONNECT ───────────────────────────────────────────────────────────
  // Give disconnected players a short grace period to reconnect via
  // rejoin_room before they're treated as having left for good. An explicit
  // leave_room (handled above) still removes them immediately — this grace
  // period only applies to unexpected disconnects (refresh, dropped wifi, etc).
  socket.on('disconnect', () => {
    console.log(`[-] Socket disconnected: ${socket.id}`);
    const { roomCode, playerId } = socket.data || {};
    if (!roomCode || !playerId) return;

    const room = getRoomByCode(roomCode);
    const player = room?.players.find(p => p.id === playerId);
    if (!player) return;

    // Mark them as having a stale connection; if they reconnect via
    // rejoin_room before the timer fires, this gets cleared and nothing
    // else happens. Otherwise, they're fully removed like before.
    player.socketId = null;
    player.disconnectedAt = Date.now();

    setTimeout(() => {
      const stillRoom = getRoomByCode(roomCode);
      const stillPlayer = stillRoom?.players.find(p => p.id === playerId);
      // Only forfeit if they never reconnected (socketId still null/stale)
      if (stillPlayer && !stillPlayer.socketId) {
        handleLeave(socket, roomCode, playerId, true);
      }
    }, RECONNECT_GRACE_PERIOD_MS);
  });
});

// ─── Helpers ───────────────────────────────────────────────────────────────

const RECONNECT_GRACE_PERIOD_MS = parseInt(process.env.RECONNECT_GRACE_PERIOD_MS) || 15000; // 15s window for rejoin_room (Part D4)


function handleLeave(socket, roomCode, playerId, isDisconnect = false) {
  const room = getRoomByCode(roomCode);
  if (!room) return;

  const player = room.players.find(p => p.id === playerId);
  if (!player) return;

  const result = leaveRoom(roomCode, playerId);
  socket.leave(roomCode);

  if (result.deleted) {
    console.log(`[Room] Deleted empty room: ${roomCode}`);
    return;
  }

  const msg = addMessage(
    roomCode,
    'System',
    `${player.name} ${isDisconnect ? 'disconnected' : 'left the game'}`,
    'system'
  );
  io.to(roomCode).emit('message_received', msg);
  io.to(roomCode).emit('player_left', {
    playerId,
    playerName: player.name,
    players: result.room.players,
    newHost: result.room.players.find(p => p.isHost),
  });

  // If game in progress, forfeit that player
  if (room.status === 'in_progress' && room.gameState) {
    if (room.gameType === 'snake-ladder') {
      const gsPlayer = room.gameState.players.find(p => p.id === playerId);
      if (gsPlayer) {
        gsPlayer.finished = true;
      }
      if (room.gameState.players[room.gameState.currentTurnIndex]?.id === playerId) {
        room.gameState.currentTurnIndex =
          (room.gameState.currentTurnIndex + 1) % room.gameState.players.length;
        room.gameState.diceRolled = false;
        room.gameState.diceResult = null;
      }
    } else {
      // Mark all their pieces as finished so turns skip them (Ludo)
      const gsPlayer = room.gameState.players.find(p => p.id === playerId);
      if (gsPlayer) {
        gsPlayer.piecesFinished = 4;
        gsPlayer.pieces.forEach(p => { p.finished = true; });
      }
      // If it was their turn, advance
      if (room.gameState.players[room.gameState.currentTurnIndex]?.id === playerId) {
        room.gameState.currentTurnIndex =
          (room.gameState.currentTurnIndex + 1) % room.gameState.players.length;
        room.gameState.diceRolled = false;
        room.gameState.validMoves = [];
      }
    }
    io.to(roomCode).emit('game_state_update', {
      gameState: room.gameState,
      forfeited: playerId,
      message: `${player.name} disconnected and forfeited`,
    });
  }

  console.log(`[Room] ${player.name} left: ${roomCode}`);
}

function sanitizeRoom(room) {
  const { gameState, messages, ...rest } = room;
  return { ...rest, messageCount: messages?.length || 0 };
}

// ─── Start Server ──────────────────────────────────────────────────────────

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`🎲 Ludo server running on http://localhost:${PORT}`);
});

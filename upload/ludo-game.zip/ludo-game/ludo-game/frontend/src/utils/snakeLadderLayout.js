// snakeLadderLayout.js — Snake & Ladder board geometry helpers
//
// Mirrors the values in backend/snakeLadderLogic.js exactly so the frontend
// renders snakes/ladders in the same places the server computes them. If you
// change one, change the other.

export const LADDERS = { 2: 38, 7: 14, 8: 31, 15: 26, 21: 42, 28: 84, 36: 44, 51: 67, 71: 91, 78: 98 };
export const SNAKES = { 16: 6, 46: 25, 49: 11, 62: 19, 64: 60, 74: 53, 89: 68, 92: 88, 95: 75, 99: 58 };

export const BOARD_SIZE = 100;
export const GRID_DIMENSION = 10;

// Convert a cell number (1-100) to its {row, col} position on a 10x10 grid,
// using the classic boustrophedon (zigzag) numbering: cell 1 is bottom-left,
// numbers increase left-to-right along the bottom row, then the next row up
// reads right-to-left, alternating all the way to cell 100 at the top-left.
export function cellToGridPosition(cellNumber) {
  const idx = cellNumber - 1; // 0-99
  const rowFromBottom = Math.floor(idx / GRID_DIMENSION); // 0 = bottom row
  const posInRow = idx % GRID_DIMENSION;
  const row = (GRID_DIMENSION - 1) - rowFromBottom; // grid row, 0 = top
  const col = (rowFromBottom % 2 === 0) ? posInRow : (GRID_DIMENSION - 1 - posInRow);
  return { row, col };
}

// Inverse helper, mostly useful for debugging/tests.
export function gridPositionToCell(row, col) {
  const rowFromBottom = (GRID_DIMENSION - 1) - row;
  const posInRow = (rowFromBottom % 2 === 0) ? col : (GRID_DIMENSION - 1 - col);
  return rowFromBottom * GRID_DIMENSION + posInRow + 1;
}

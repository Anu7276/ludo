// boardLayout.js — Ludo board cell coordinates and layout helpers
//
// Supports 4-player (15x15 grid, 56-cell ring) and 6-player (21x21 grid, 84-cell ring).
// Geometry verified programmatically.

export const PLAYER_COLORS = ['red', 'yellow', 'green', 'blue', 'purple', 'cyan'];

export const COLOR_HEX = {
  red:    '#EF4444',
  yellow: '#FBBF24',
  green:  '#22C55E',
  blue:   '#3B82F6',
  purple: '#A855F7',
  cyan:   '#06B6D4',
};

export const COLOR_LIGHT = {
  red:    '#FECACA',
  yellow: '#FDE68A',
  green:  '#BBF7D0',
  blue:   '#BFDBFE',
  purple: '#E9D5FF',
  cyan:   '#CFFAFE',
};

// ─── 4-PLAYER BOARD (15×15 grid) ─────────────────────────────────────────────

export const PLAYER_START_POSITIONS = [0, 14, 28, 42];

export const BOARD_SIZE = 56;
export const MAIN_RING_STEPS = 55;
export const HOME_COLUMN_LENGTH = 5;
export const FINISH_RELATIVE_POS = MAIN_RING_STEPS + HOME_COLUMN_LENGTH; // 60

export const LUDO_PATH = [
  [6,1],[6,2],[6,3],[6,4],[6,5],[6,6],[5,6],[4,6],[3,6],[2,6],[1,6],[0,6],[0,7],
  [0,8],[1,8],[2,8],[3,8],[4,8],[5,8],[6,8],[6,9],[6,10],[6,11],[6,12],[6,13],[6,14],
  [7,14],[8,14],[8,13],[8,12],[8,11],[8,10],[8,9],[8,8],[9,8],[10,8],[11,8],[12,8],[13,8],
  [14,8],[14,7],[14,6],[13,6],[12,6],[11,6],[10,6],[9,6],[8,6],[8,5],[8,4],[8,3],[8,2],
  [8,1],[8,0],[7,0],[6,0],
];

export const HOME_COLUMNS = [
  [[7,1],[7,2],[7,3],[7,4],[7,5]],     // Red
  [[1,7],[2,7],[3,7],[4,7],[5,7]],     // Yellow
  [[7,13],[7,12],[7,11],[7,10],[7,9]], // Green
  [[13,7],[12,7],[11,7],[10,7],[9,7]], // Blue
];

export const CENTER_CELL = [7, 7];

export const HOME_BASES = {
  0: { rows: [0, 5], cols: [0, 5] },   // Red top-left
  1: { rows: [0, 5], cols: [9, 14] },  // Yellow top-right
  2: { rows: [9, 14], cols: [9, 14] }, // Green bottom-right
  3: { rows: [9, 14], cols: [0, 5] },  // Blue bottom-left
};

export const HOME_PAWN_POSITIONS = {
  0: [[2,2],[2,4],[4,2],[4,4]],
  1: [[2,10],[2,12],[4,10],[4,12]],
  2: [[10,10],[10,12],[12,10],[12,12]],
  3: [[10,2],[10,4],[12,2],[12,4]],
};

export const SAFE_POSITIONS = new Set([0, 8, 14, 22, 28, 36, 42, 50]);

export function getPlayerPieceCell(playerIndex, relPos) {
  if (relPos < 0) return null;
  if (relPos >= MAIN_RING_STEPS) {
    const homeColIdx = relPos - MAIN_RING_STEPS;
    if (homeColIdx >= HOME_COLUMN_LENGTH) return CENTER_CELL;
    return HOME_COLUMNS[playerIndex]?.[homeColIdx] || CENTER_CELL;
  }
  const start = PLAYER_START_POSITIONS[playerIndex];
  const absPos = (start + relPos) % BOARD_SIZE;
  return LUDO_PATH[absPos];
}

export function relativeToAbsolute(playerIndex, relPos) {
  if (relPos < 0 || relPos >= MAIN_RING_STEPS) return null;
  const start = PLAYER_START_POSITIONS[playerIndex];
  return (start + relPos) % BOARD_SIZE;
}

export function isSafeAbsolutePos(absPos) {
  return SAFE_POSITIONS.has(absPos);
}


// ─── 6-PLAYER BOARD (21×21 grid) ─────────────────────────────────────────────
//
// Ring: 84-cell perimeter path with 2 strategic bumps for valid home column entries.
// Ring verified: no duplicate cells, all cells adjacent, all 6 players have valid
// home column entry cells adjacent to their ring entry positions.
//
// Home columns: 9 cells each (6-player home columns are longer due to bigger board).
// Constants use _6P suffix to avoid collisions with 4-player exports.

export const BOARD_SIZE_6P        = 84;
export const MAIN_RING_STEPS_6P   = 83;  // relPos 0-82 = on ring, 83+ = home column
export const HOME_COLUMN_LENGTH_6P = 9;  // relPos 83-91 = home column cells
export const FINISH_RELATIVE_POS_6P = MAIN_RING_STEPS_6P + HOME_COLUMN_LENGTH_6P; // 92

export const PLAYER_START_POSITIONS_6P = [0, 14, 28, 42, 56, 70];

// Safe positions: each player's start + one midpoint per arm
export const SAFE_POSITIONS_6P = new Set([0, 7, 14, 21, 28, 35, 42, 49, 56, 63, 70, 77]);

// The 84-cell ring path, starting at Red's start cell [9,0].
// Design: outer perimeter of 21×21 grid with 2 strategic bumps.
// Bump 1 (top-right, idx 27-28): [1,17],[1,18] — allows Green player home col entry
// Bump 2 (bottom-left, idx 68-70): [19,3],[19,2],[19,1] — allows Blue player home col entry
export const LUDO_PATH_6P = [
  [9,0],[8,0],[7,0],[6,0],[5,0],[4,0],[3,0],[2,0],[1,0],[0,0],
  [0,1],[0,2],[0,3],[0,4],[0,5],[0,6],[0,7],[0,8],[0,9],[0,10],
  [0,11],[0,12],[0,13],[0,14],[0,15],[0,16],[0,17],[1,17],[1,18],[0,18],
  [0,19],[0,20],[1,20],[2,20],[3,20],[4,20],[5,20],[6,20],[7,20],[8,20],
  [9,20],[10,20],[11,20],[12,20],[13,20],[14,20],[15,20],[16,20],[17,20],[18,20],
  [19,20],[20,20],[20,19],[20,18],[20,17],[20,16],[20,15],[20,14],[20,13],[20,12],
  [20,11],[20,10],[20,9],[20,8],[20,7],[20,6],[20,5],[20,4],[20,3],[19,3],
  [19,2],[19,1],[20,1],[20,0],[19,0],[18,0],[17,0],[16,0],[15,0],[14,0],
  [13,0],[12,0],[11,0],[10,0],
];

// 6-player home columns (9 cells each, ordered entrance → near-center).
// Each column's first cell is adjacent to that player's ring entry position.
// Arranged to avoid all ring cells and each other.
export const HOME_COLUMNS_6P = [
  // Red (P0): entry ring=[10,0], adj=[10,1], goes RIGHT toward center
  [[10,1],[10,2],[10,3],[10,4],[10,5],[10,6],[10,7],[10,8],[10,9]],
  // Yellow (P1): entry ring=[0,4], adj=[1,4], goes DOWN toward center
  [[1,4],[2,4],[3,4],[4,4],[5,4],[6,4],[7,4],[8,4],[9,4]],
  // Green (P2): entry ring=[1,17], adj=[1,16], goes DOWN col 16
  [[1,16],[2,16],[3,16],[4,16],[5,16],[6,16],[7,16],[8,16],[9,16]],
  // Blue (P3): entry ring=[10,20], adj=[10,19], goes LEFT toward center
  [[10,19],[10,18],[10,17],[10,16],[10,15],[10,14],[10,13],[10,12],[10,11]],
  // Purple (P4): entry ring=[20,16], adj=[19,16], goes UP col 16
  [[19,16],[18,16],[17,16],[16,16],[15,16],[14,16],[13,16],[12,16],[11,16]],
  // Cyan (P5): entry ring=[19,3], adj=[19,4], goes UP col 4
  [[19,4],[18,4],[17,4],[16,4],[15,4],[14,4],[13,4],[12,4],[11,4]],
];

// Shared center finish area for 6-player (finish pieces displayed there)
export const CENTER_CELL_6P = [10, 10];

// Home base areas (visual zones, 6×6 each) for 6-player
export const HOME_BASES_6P = {
  0: { rows: [0, 5],  cols: [0, 5] },   // Red top-left
  1: { rows: [0, 5],  cols: [8, 13] },  // Yellow top-center
  2: { rows: [0, 5],  cols: [15, 20] }, // Green top-right
  3: { rows: [15, 20], cols: [15, 20] }, // Blue bottom-right
  4: { rows: [15, 20], cols: [8, 13] }, // Purple bottom-center
  5: { rows: [15, 20], cols: [0, 5] },  // Cyan bottom-left
};

// Pawn parking spots inside each 6-player home base
// Slots moved to rows 2,4 (top zones) and 16,18 (bottom zones) to avoid ring conflicts
export const HOME_PAWN_POSITIONS_6P = {
  0: [[2,1],[2,3],[4,1],[4,3]],       // Red
  1: [[2,9],[2,11],[4,9],[4,11]],     // Yellow
  2: [[2,16],[2,18],[4,16],[4,18]],   // Green
  3: [[16,16],[16,18],[18,16],[18,18]], // Blue
  4: [[16,9],[16,11],[18,9],[18,11]], // Purple
  5: [[16,1],[16,3],[18,1],[18,3]],   // Cyan
};

// Get the [row, col] cell for a player's piece in a 6-player game
export function getPlayerPieceCell6P(playerIndex, relPos) {
  if (relPos < 0) return null;
  if (relPos >= MAIN_RING_STEPS_6P) {
    const homeColIdx = relPos - MAIN_RING_STEPS_6P;
    if (homeColIdx >= HOME_COLUMN_LENGTH_6P) return CENTER_CELL_6P;
    return HOME_COLUMNS_6P[playerIndex]?.[homeColIdx] || CENTER_CELL_6P;
  }
  const start = PLAYER_START_POSITIONS_6P[playerIndex];
  const absPos = (start + relPos) % BOARD_SIZE_6P;
  return LUDO_PATH_6P[absPos];
}

export function relativeToAbsolute6P(playerIndex, relPos) {
  if (relPos < 0 || relPos >= MAIN_RING_STEPS_6P) return null;
  const start = PLAYER_START_POSITIONS_6P[playerIndex];
  return (start + relPos) % BOARD_SIZE_6P;
}

export function isSafeAbsolutePos6P(absPos) {
  return SAFE_POSITIONS_6P.has(absPos);
}

// socket.js — Socket.io client singleton

import { io } from 'socket.io-client';

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:5000';

const socket = io(BACKEND_URL, {
  autoConnect: false,
  // D4: enable reconnection so the server's 15s grace period can be used;
  // on reconnect GamePage emits rejoin_room to resume the player's seat.
  reconnection: true,
  reconnectionAttempts: 5,
  reconnectionDelay: 1000,
  reconnectionDelayMax: 4000,
});

export default socket;

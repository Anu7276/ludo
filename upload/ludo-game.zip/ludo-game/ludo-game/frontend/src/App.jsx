// App.jsx
import React, { useState } from 'react';
import './index.css';
import HomePage from './pages/HomePage';
import LobbyPage from './pages/LobbyPage';
import GamePage from './pages/GamePage';
import GroupPage from './pages/GroupPage';

export default function App() {
  const [page, setPage] = useState('home'); // 'home' | 'lobby' | 'game' | 'group'
  const [gameContext, setGameContext] = useState(null);
  // gameContext carries: { roomCode, player, room, gameState, isHost, gameType }
  // For 'lobby': gameContext may carry { gameType } pre-selected from game-select screen
  // For 'group': no context needed

  const navigate = (to, ctx = null) => {
    setPage(to);
    if (ctx !== null) setGameContext(ctx);
  };

  return (
    <>
      {page === 'home'  && <HomePage  navigate={navigate} />}
      {page === 'lobby' && <LobbyPage navigate={navigate} gameContext={gameContext} />}
      {page === 'game'  && <GamePage  navigate={navigate} gameContext={gameContext} />}
      {page === 'group' && <GroupPage navigate={navigate} />}
    </>
  );
}

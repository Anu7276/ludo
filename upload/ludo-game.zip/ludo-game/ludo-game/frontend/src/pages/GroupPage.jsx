// pages/GroupPage.jsx — Friend Groups (Part C)
import React, { useState, useEffect } from 'react';
import socket from '../services/socket';
import styles from './GroupPage.module.css';

const AVATAR_OPTIONS = ['🦁','🐯','🦊','🐺','🐻','🦝','🐸','🐙','🦄','🐉','👾','🤖'];

export default function GroupPage({ navigate }) {
  const [tab, setTab] = useState('create'); // 'create' | 'join'
  const [playerName, setPlayerName] = useState('');
  const [groupName, setGroupName] = useState('');
  const [groupCode, setGroupCode] = useState('');
  const [avatar, setAvatar] = useState(null);
  const [myGroup, setMyGroup] = useState(null);
  const [myMember, setMyMember] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [connected, setConnected] = useState(socket.connected);
  const [inviteStatus, setInviteStatus] = useState('');

  useEffect(() => {
    if (!socket.connected) socket.connect();
    setConnected(socket.connected);

    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));

    socket.on('group_created', (data) => {
      setLoading(false);
      setMyGroup(data.group);
      setMyMember(data.member);
    });

    socket.on('group_joined', (data) => {
      setLoading(false);
      setMyGroup(data.group);
      setMyMember(data.member);
    });

    socket.on('group_member_joined', (data) => {
      setMyGroup(data.group);
    });

    socket.on('room_created', (data) => {
      // After creating a room from the group page, invite group members then navigate to game
      if (myGroup && myMember) {
        socket.emit('invite_to_room', {
          groupCode: myGroup.groupCode,
          roomCode: data.roomCode,
        });
      }
      navigate('game', {
        roomCode: data.roomCode,
        player: data.player,
        room: data.room,
        gameType: data.room.gameType,
        gameState: null,
        isHost: true,
      });
    });

    socket.on('room_joined', (data) => {
      navigate('game', {
        roomCode: data.roomCode,
        player: data.player,
        room: data.room,
        gameType: data.room.gameType,
        gameState: null,
        isHost: false,
      });
    });

    socket.on('room_invite', (data) => {
      const accept = window.confirm(
        `${data.invitedBy} invited you to play ${data.gameType === 'snake-ladder' ? '🐍 Snake & Ladder' : '🎲 Ludo'}!\n` +
        `Room: ${data.roomName} (${data.roomCode})\n\nJoin now?`
      );
      if (accept) {
        const name = playerName.trim();
        if (!name) {
          alert('Enter your name first, then accept the invite.');
          return;
        }
        socket.emit('join_room', {
          roomCode: data.roomCode,
          playerName: name,
          avatar: avatar || null,
        });
        // room_joined handler (registered above) will navigate to 'game'
      }
    });

    socket.on('invite_sent', (data) => {
      setInviteStatus(`Invited ${data.invitedCount} group member(s) ✓`);
      setTimeout(() => setInviteStatus(''), 4000);
    });

    socket.on('error', (data) => {
      setLoading(false);
      setError(data.message);
    });

    return () => {
      socket.off('connect');
      socket.off('disconnect');
      socket.off('group_created');
      socket.off('group_joined');
      socket.off('group_member_joined');
      socket.off('room_created');
      socket.off('room_joined');
      socket.off('room_invite');
      socket.off('invite_sent');
      socket.off('error');
    };
  }, [navigate, myGroup, myMember]);

  const handleCreate = () => {
    if (!playerName.trim()) return setError('Enter your name');
    setError('');
    setLoading(true);
    socket.emit('create_group', {
      groupName: groupName.trim() || `${playerName}'s Crew`,
      playerName: playerName.trim(),
    });
  };

  const handleJoin = () => {
    if (!playerName.trim()) return setError('Enter your name');
    if (!groupCode.trim()) return setError('Enter a group code');
    setError('');
    setLoading(true);
    socket.emit('join_group', {
      groupCode: groupCode.trim().toUpperCase(),
      playerName: playerName.trim(),
    });
  };

  const handleStartGameWithGroup = (gameType) => {
    if (!playerName.trim()) return;
    // Creates a room (server.js room_created fires, then we invite group members)
    socket.emit('create_room', {
      roomName: `${myGroup?.groupName || playerName}'s Game`,
      maxPlayers: Math.min(Math.max(myGroup?.members?.length || 2, 2), 6),
      playerName: playerName.trim(),
      gameType,
      avatar,
    });
  };

  // ── Logged into a group ───────────────────────────────────────────────────
  if (myGroup) {
    return (
      <div className={styles.page}>
        <div className={styles.container}>
          <div className={styles.header}>
            <button className={styles.backBtn} onClick={() => navigate('home')}>← Home</button>
            <h1 className={styles.title}>👥 {myGroup.groupName}</h1>
            <div className={styles.groupCodeBadge}>{myGroup.groupCode}</div>
          </div>

          <div className={styles.shareBox}>
            <p className={styles.shareText}>Share this code so friends can join:</p>
            <div className={styles.shareCode}>{myGroup.groupCode}</div>
          </div>

          <div className={styles.memberSection}>
            <div className={styles.sectionLabel}>
              Members ({myGroup.members.length})
            </div>
            {myGroup.members.map(m => (
              <div key={m.id} className={styles.memberRow}>
                <span className={styles.memberDot} />
                <span className={styles.memberName}>{m.name}</span>
                {m.id === myMember?.id && <span className={styles.youBadge}>You</span>}
                {m.isCreator && <span className={styles.creatorBadge}>Creator</span>}
              </div>
            ))}
          </div>

          {inviteStatus && (
            <div className={styles.inviteStatus}>{inviteStatus}</div>
          )}

          <div className={styles.startSection}>
            <div className={styles.sectionLabel}>Start a game with this group</div>
            <button
              className={`btn btn-primary ${styles.startBtn}`}
              onClick={() => handleStartGameWithGroup('ludo')}
            >
              🎲 Play Ludo
            </button>
            <button
              className={`btn ${styles.startBtnAlt}`}
              onClick={() => handleStartGameWithGroup('snake-ladder')}
            >
              🐍 Play Snake & Ladder
            </button>
          </div>

          <button
            className={styles.lobbyBtn}
            onClick={() => navigate('lobby', { gameType: 'ludo' })}
          >
            Or go to the open lobby →
          </button>
        </div>
      </div>
    );
  }

  // ── Not yet in a group ────────────────────────────────────────────────────
  return (
    <div className={styles.page}>
      <div className={styles.container}>
        <div className={styles.header}>
          <button className={styles.backBtn} onClick={() => navigate('home')}>← Back</button>
          <h1 className={styles.title}>👥 Friend Groups</h1>
          <div className={styles.connDot} data-connected={connected} />
        </div>

        <p className={styles.intro}>
          Create a private group with friends. Share the group code so they can join,
          then start any game together with one tap.
        </p>

        {/* Name */}
        <div className={styles.nameSection}>
          <label className={styles.label}>Your Name</label>
          <input
            className="input-field"
            placeholder="Enter your name…"
            value={playerName}
            maxLength={20}
            onChange={e => { setPlayerName(e.target.value); setError(''); }}
          />
          <label className={styles.label} style={{ marginTop: 10 }}>Avatar (optional)</label>
          <div className={styles.avatarPicker}>
            {AVATAR_OPTIONS.map(em => (
              <button
                key={em}
                className={`${styles.avatarBtn} ${avatar === em ? styles.avatarBtnActive : ''}`}
                onClick={() => setAvatar(avatar === em ? null : em)}
              >
                {em}
              </button>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div className={styles.tabs}>
          <button
            className={`${styles.tab} ${tab === 'create' ? styles.tabActive : ''}`}
            onClick={() => setTab('create')}
          >Create Group</button>
          <button
            className={`${styles.tab} ${tab === 'join' ? styles.tabActive : ''}`}
            onClick={() => setTab('join')}
          >Join Group</button>
        </div>

        {error && <div className={styles.error}>{error}</div>}

        {tab === 'create' && (
          <div className={styles.tabContent}>
            <label className={styles.label}>Group Name (optional)</label>
            <input
              className="input-field"
              placeholder={`${playerName || 'My'}'s Crew`}
              value={groupName}
              maxLength={30}
              onChange={e => setGroupName(e.target.value)}
              style={{ marginBottom: 16 }}
              onKeyDown={e => e.key === 'Enter' && handleCreate()}
            />
            <button
              className={`btn btn-primary ${styles.actionBtn}`}
              disabled={loading || !playerName.trim()}
              onClick={handleCreate}
            >
              {loading ? 'Creating…' : '✨ Create Group'}
            </button>
          </div>
        )}

        {tab === 'join' && (
          <div className={styles.tabContent}>
            <div className={styles.joinInput}>
              <input
                className="input-field"
                placeholder="Group code (e.g. GABC1)…"
                value={groupCode}
                maxLength={6}
                style={{ textTransform: 'uppercase', letterSpacing: '2px', fontWeight: 700 }}
                onChange={e => { setGroupCode(e.target.value.toUpperCase()); setError(''); }}
                onKeyDown={e => e.key === 'Enter' && handleJoin()}
              />
              <button
                className={`btn btn-primary ${styles.joinBtn}`}
                disabled={loading || !playerName.trim() || !groupCode.trim()}
                onClick={handleJoin}
              >
                {loading ? '…' : 'Join →'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

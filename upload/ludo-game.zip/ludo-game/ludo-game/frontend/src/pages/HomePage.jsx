// pages/HomePage.jsx
import React from 'react';
import styles from './HomePage.module.css';

const GAMES = [
  {
    type: 'ludo',
    icon: '🎲',
    name: 'Ludo',
    desc: '2–6 players · Race all 4 pieces home',
    color: '#6366F1',
  },
  {
    type: 'snake-ladder',
    icon: '🐍',
    name: 'Snake & Ladder',
    desc: '2–6 players · Climb ladders, dodge snakes',
    color: '#22C55E',
  },
];

const FEATURES = [
  { icon: '💬', title: 'In-game Chat', desc: 'Talk strategy (or trash)' },
  { icon: '⚡', title: 'Instant Play', desc: 'No signup, just pick a name' },
  { icon: '👥', title: 'Friend Groups', desc: 'Invite your crew in one click' },
  { icon: '📱', title: 'Any Device', desc: 'Works on mobile & desktop' },
];

export default function HomePage({ navigate }) {
  return (
    <div className={styles.page}>
      {/* Stars background */}
      <div className={styles.stars} aria-hidden="true">
        {Array.from({ length: 60 }).map((_, i) => (
          <div key={i} className={styles.star} style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 3}s`,
            width: `${Math.random() * 2 + 1}px`,
            height: `${Math.random() * 2 + 1}px`,
          }} />
        ))}
      </div>

      <div className={styles.content}>
        {/* Hero */}
        <div className={styles.hero}>
          <h1 className={styles.title}>
            <span className={styles.titleMain}>GAME</span>
            <span className={styles.titleSub}>NIGHT</span>
          </h1>
          <p className={styles.subtitle}>
            Multiplayer board games, real-time with friends.
            <br />Pick a game and jump right in.
          </p>
        </div>

        {/* A2: Game selection cards */}
        <div className={styles.gameCards}>
          {GAMES.map(game => (
            <button
              key={game.type}
              className={styles.gameCard}
              style={{ '--game-color': game.color }}
              onClick={() => navigate('lobby', { gameType: game.type })}
            >
              <span className={styles.gameCardIcon}>{game.icon}</span>
              <div className={styles.gameCardText}>
                <span className={styles.gameCardName}>{game.name}</span>
                <span className={styles.gameCardDesc}>{game.desc}</span>
              </div>
              <span className={styles.gameCardArrow}>→</span>
            </button>
          ))}
        </div>

        {/* C3: Friends Group entry */}
        <button
          className={styles.groupBtn}
          onClick={() => navigate('group')}
        >
          👥 Play with a Friend Group
        </button>

        {/* Features */}
        <div className={styles.features}>
          {FEATURES.map(f => (
            <div key={f.title} className={styles.featureCard}>
              <span className={styles.featureIcon}>{f.icon}</span>
              <div>
                <div className={styles.featureTitle}>{f.title}</div>
                <div className={styles.featureDesc}>{f.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <footer className={styles.footer}>
        Built for real-time fun · Socket.io + React
      </footer>
    </div>
  );
}


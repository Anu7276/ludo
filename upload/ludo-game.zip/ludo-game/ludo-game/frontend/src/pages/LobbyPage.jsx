// pages/LobbyPage.jsx
import React, { useState, useEffect, useCallback } from 'react';
import socket from '../services/socket';
import styles from './LobbyPage.module.css';

const GAME_TYPE_LABELS = { 'ludo': '🎲 Ludo', 'snake-ladder': '🐍 S&L' };
const AVATAR_OPTIONS = ['🦁','🐯','🦊','🐺','🐻','🦝','🐸','🐙','🦄','🐉','👾','🤖'];

export default function LobbyPage({ navigate, gameContext }) {
  // A2: gameType may be pre-selected from the game selection screen
  const preselectedGameType = gameContext?.gameType || 'ludo';

  const [tab, setTab] = useState('join');
  const [playerName, setPlayerName] = useState('');
  const [roomName, setRoomName] = useState('');
  const [maxPlayers, setMaxPlayers] = useState(4);
  const [roomCode, setRoomCode] = useState('');
  const [gameType, setGameType] = useState(preselectedGameType); // A2
  const [avatar, setAvatar] = useState(null); // D2
  const [availableRooms, setAvailableRooms] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [connected, setConnected] = useState(false);

  // Connect socket
  useEffect(() => {
    if (!socket.connected) socket.connect();
    setConnected(socket.connected);

    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));

    socket.on('room_created', (data) => {
      setLoading(false);
      navigate('game', {
        roomCode: data.roomCode,
        player: data.player,
        room: data.room,
        gameType: data.room.gameType,
        gameState: null,
        isHost: true,
      });
    });

    socket.on('room_joined', (data) => {
      setLoading(false);
      navigate('game', {
        roomCode: data.roomCode,
        player: data.player,
        room: data.room,
        gameType: data.room.gameType,
        gameState: null,
        isHost: false,
      });
    });

    socket.on('join_error', (data) => {
      setLoading(false);
      setError(data.message);
    });

    socket.on('error', (data) => {
      setLoading(false);
      setError(data.message);
    });

    socket.on('room_invite', (data) => {
      const accept = window.confirm(
        `${data.invitedBy} invited you to play ${data.gameType === 'snake-ladder' ? '🐍 Snake & Ladder' : '🎲 Ludo'}!\n` +
        `Room: ${data.roomName} (${data.roomCode})\n\nJoin now?`
      );
      if (accept) {
        const name = playerName.trim();
        if (!name) {
          alert('Enter your name in the lobby first, then accept invites.');
          return;
        }
        setLoading(true);
        socket.emit('join_room', {
          roomCode: data.roomCode,
          playerName: name,
          avatar: avatar || null,
        });
        // The existing room_joined handler in this effect will navigate to 'game'
      }
    });

    return () => {
      socket.off('connect');
      socket.off('disconnect');
      socket.off('room_created');
      socket.off('room_joined');
      socket.off('join_error');
      socket.off('error');
      socket.off('room_invite');
    };
  }, [navigate]);

  // Poll available rooms
  const fetchRooms = useCallback(async () => {
    try {
      const res = await fetch('/api/rooms');
      const data = await res.json();
      setAvailableRooms(data);
    } catch {}
  }, []);

  useEffect(() => {
    fetchRooms();
    const interval = setInterval(fetchRooms, 2500);
    return () => clearInterval(interval);
  }, [fetchRooms]);

  const handleCreate = () => {
    if (!playerName.trim()) return setError('Enter your name');
    setError('');
    setLoading(true);
    socket.emit('create_room', {
      roomName: roomName.trim() || `${playerName}'s Game`,
      maxPlayers: parseInt(maxPlayers),
      playerName: playerName.trim(),
      gameType, // A2
      avatar,   // D2
    });
  };

  const handleJoin = (code = roomCode) => {
    if (!playerName.trim()) return setError('Enter your name');
    if (!code.trim()) return setError('Enter a room code');
    setError('');
    setLoading(true);
    socket.emit('join_room', {
      roomCode: code.trim().toUpperCase(),
      playerName: playerName.trim(),
      avatar, // D2
    });
  };

  return (
    <div className={styles.page}>
      <div className={styles.container}>
        {/* Header */}
        <div className={styles.header}>
          <button className={styles.backBtn} onClick={() => navigate('home')}>← Back</button>
          <h1 className={styles.title}>🎲 Game Lobby</h1>
          <div className={styles.connDot} data-connected={connected} title={connected ? 'Connected' : 'Connecting...'} />
        </div>

        {/* Name + Avatar row (D2) */}
        <div className={styles.nameSection}>
          <label className={styles.label}>Your Name</label>
          <input
            className="input-field"
            placeholder="Enter your player name…"
            value={playerName}
            maxLength={20}
            onChange={e => { setPlayerName(e.target.value); setError(''); }}
            onKeyDown={e => e.key === 'Enter' && (tab === 'create' ? handleCreate() : handleJoin())}
          />
          <label className={styles.label} style={{ marginTop: 10 }}>Avatar (optional)</label>
          <div className={styles.avatarPicker}>
            {AVATAR_OPTIONS.map(em => (
              <button
                key={em}
                className={`${styles.avatarBtn} ${avatar === em ? styles.avatarBtnActive : ''}`}
                onClick={() => setAvatar(avatar === em ? null : em)}
                title={em}
              >
                {em}
              </button>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div className={styles.tabs}>
          <button
            className={`${styles.tab} ${tab === 'join' ? styles.tabActive : ''}`}
            onClick={() => setTab('join')}
          >Join Game</button>
          <button
            className={`${styles.tab} ${tab === 'create' ? styles.tabActive : ''}`}
            onClick={() => setTab('create')}
          >Create Room</button>
        </div>

        {error && <div className={styles.error}>{error}</div>}

        {/* JOIN TAB */}
        {tab === 'join' && (
          <div className={styles.tabContent}>
            <div className={styles.joinInput}>
              <input
                className="input-field"
                placeholder="Room code (e.g. ABC12)…"
                value={roomCode}
                maxLength={6}
                style={{ textTransform: 'uppercase', letterSpacing: '2px', fontWeight: 700 }}
                onChange={e => { setRoomCode(e.target.value.toUpperCase()); setError(''); }}
                onKeyDown={e => e.key === 'Enter' && handleJoin()}
              />
              <button
                className={`btn btn-primary ${styles.joinBtn}`}
                disabled={loading || !playerName.trim() || !roomCode.trim()}
                onClick={() => handleJoin()}
              >
                {loading ? '…' : 'Join →'}
              </button>
            </div>

            {/* Available rooms list (D1: tagged by gameType) */}
            <div className={styles.roomsSection}>
              <div className={styles.roomsHeader}>
                <span>Open Rooms</span>
                <span className={styles.roomCount}>{availableRooms.length}</span>
              </div>
              {availableRooms.length === 0 ? (
                <div className={styles.noRooms}>
                  No open rooms yet. Create one!
                </div>
              ) : (
                <div className={styles.roomList}>
                  {availableRooms.map(room => (
                    <div key={room.roomCode} className={styles.roomItem}>
                      <div className={styles.roomInfo}>
                        <div className={styles.roomNameRow}>
                          <span className={styles.roomName}>{room.roomName}</span>
                          {/* D1: game type badge */}
                          <span className={styles.gameTypeBadge}>
                            {GAME_TYPE_LABELS[room.gameType] || room.gameType}
                          </span>
                        </div>
                        <span className={styles.roomMeta}>
                          {room.roomCode} · {room.playerCount}/{room.maxPlayers} players
                        </span>
                        <div className={styles.roomPlayers}>
                          {room.players.map(p => (
                            <span key={p.name} className={styles.roomPlayer} style={{
                              color: { red:'#EF4444', yellow:'#FBBF24', green:'#22C55E', blue:'#3B82F6' }[p.color] || '#E2E8F0'
                            }}>
                              {p.avatar || '●'} {p.name}
                            </span>
                          ))}
                        </div>
                      </div>
                      <button
                        className={`btn btn-primary ${styles.quickJoinBtn}`}
                        disabled={loading || !playerName.trim()}
                        onClick={() => handleJoin(room.roomCode)}
                      >
                        Join
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* CREATE TAB */}
        {tab === 'create' && (
          <div className={styles.tabContent}>
            <label className={styles.label}>Room Name (optional)</label>
            <input
              className="input-field"
              placeholder={`${playerName || 'My'}'s Game`}
              value={roomName}
              maxLength={30}
              onChange={e => setRoomName(e.target.value)}
              style={{ marginBottom: 16 }}
            />

            {/* A2: game type selector */}
            <label className={styles.label}>Game</label>
            <div className={styles.gameTypePicker}>
              {[
                { type: 'ludo', label: '🎲 Ludo', desc: '2-6 players, piece racing' },
                { type: 'snake-ladder', label: '🐍 Snake & Ladder', desc: '2-6 players, fast-paced' },
              ].map(opt => (
                <button
                  key={opt.type}
                  className={`${styles.gameTypeBtn} ${gameType === opt.type ? styles.gameTypeBtnActive : ''}`}
                  onClick={() => setGameType(opt.type)}
                >
                  <span className={styles.gameTypeBtnLabel}>{opt.label}</span>
                  <span className={styles.gameTypeBtnDesc}>{opt.desc}</span>
                </button>
              ))}
            </div>

            <label className={styles.label} style={{ marginTop: 4 }}>Max Players</label>
            <div className={styles.playerCountPicker}>
              {[2, 3, 4, 5, 6].map(n => (
                <button
                  key={n}
                  className={`${styles.countBtn} ${maxPlayers === n ? styles.countBtnActive : ''}`}
                  onClick={() => setMaxPlayers(n)}
                >
                  {n}
                </button>
              ))}
            </div>

            <div className={styles.colorPreview}>
              {['#EF4444','#FBBF24','#22C55E','#3B82F6','#A855F7','#06B6D4'].slice(0, maxPlayers).map((c, i) => (
                <span key={i} className={styles.colorSwatch} style={{ background: c }} />
              ))}
            </div>

            <button
              className={`btn btn-primary ${styles.createBtn}`}
              disabled={loading || !playerName.trim()}
              onClick={handleCreate}
            >
              {loading ? 'Creating…' : '🎮 Create & Join'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

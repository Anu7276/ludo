// pages/GamePage.jsx
import React, { useState, useEffect, useCallback, useRef } from 'react';
import socket from '../services/socket';
import Board from '../components/Board';
import SnakeLadderBoard from '../components/SnakeLadderBoard';
import PlayerPanel from '../components/PlayerPanel';
import DiceRoller from '../components/DiceRoller';
import Chat from '../components/Chat';
import GameOver from '../components/GameOver';
import styles from './GamePage.module.css';
import { COLOR_HEX } from '../utils/boardLayout';

const GAME_TYPE_LABELS = {
  'ludo': '🎲 Ludo',
  'snake-ladder': '🐍 Snake & Ladder',
};

export default function GamePage({ navigate, gameContext }) {
  const { roomCode, player, isHost: initialIsHost } = gameContext || {};
  const gameType = gameContext?.room?.gameType || gameContext?.gameType || 'ludo';

  const [room, setRoom] = useState(gameContext?.room || null);
  const [gameState, setGameState] = useState(gameContext?.gameState || null);
  const [players, setPlayers] = useState(gameContext?.room?.players || []);
  const [messages, setMessages] = useState([]);
  const [isHost, setIsHost] = useState(initialIsHost || false);
  const [gameOver, setGameOver] = useState(null);
  const [notification, setNotification] = useState('');
  const notifTimerRef = useRef(null);

  const myPlayerId = player?.id;
  const isSnakeLadder = gameType === 'snake-ladder';

  const showNotif = useCallback((msg) => {
    setNotification(msg);
    clearTimeout(notifTimerRef.current);
    notifTimerRef.current = setTimeout(() => setNotification(''), 3000);
  }, []);

  // D4: attempt to rejoin on socket reconnect if we have a stored roomCode + playerId
  useEffect(() => {
    const handleReconnect = () => {
      if (roomCode && myPlayerId) {
        socket.emit('rejoin_room', { roomCode, playerId: myPlayerId });
      }
    };
    socket.on('connect', handleReconnect);
    return () => socket.off('connect', handleReconnect);
  }, [roomCode, myPlayerId]);

  useEffect(() => {
    if (!socket.connected) socket.connect();

    socket.on('connect_error', (error) => {
      showNotif(`⚠️ Connection error: ${error?.message || 'Unable to reach server'}`);
    });

    socket.on('disconnect', (reason) => {
      if (reason !== 'io client disconnect') {
        showNotif('🔌 Disconnected — attempting to reconnect…');
      }
    });

    // Game events
    socket.on('game_started', (data) => {
      setGameState(data.gameState);
      setPlayers(data.players);
      showNotif('Game started! Good luck! 🎲');
    });

    socket.on('dice_rolled', (data) => {
      setGameState(data.gameState);
      if (data.autoAdvanced) {
        showNotif(`No valid moves — turn skipped`);
      }
    });

    socket.on('piece_moved', (data) => {
      setGameState(data.gameState);
      if (data.capturedPieces?.length > 0) {
        showNotif('Piece captured! 🎯');
      }
      if (data.hitSnake) {
        showNotif(`🐍 Snake! Down to ${data.hitSnake.to}`);
      }
      if (data.hitLadder) {
        showNotif(`🪜 Ladder! Up to ${data.hitLadder.to}`);
      }
      // Only show bonus turn if the game is still in progress
      if (data.bonusTurn && data.playerId === myPlayerId && data.gameState?.status !== 'finished') {
        showNotif('Bonus turn! 🎉');
      }
    });

    socket.on('game_state_update', (data) => {
      setGameState(data.gameState);
    });

    socket.on('game_over', (data) => {
      setGameState(data.gameState);
      setGameOver(data);
    });

    socket.on('player_joined', (data) => {
      setPlayers(data.players);
      showNotif(`${data.player.name} joined!`);
    });

    socket.on('player_left', (data) => {
      setPlayers(data.players);
      if (data.newHost?.id === myPlayerId) {
        setIsHost(true);
        showNotif("You're now the host");
      }
    });

    socket.on('message_received', (msg) => {
      setMessages(prev => [...prev, msg]);
    });

    socket.on('lobby_reset', (data) => {
      setGameState(null);
      setGameOver(null);
      setRoom(data.room);
      setMessages([]);
      showNotif('Room reset — ready to play again!');
    });

    // D4: on rejoin confirmation, restore full game state
    socket.on('room_rejoined', (data) => {
      if (data.gameState) setGameState(data.gameState);
      if (data.room?.players) setPlayers(data.room.players);
      showNotif('Reconnected ✓');
    });

    socket.on('error', (data) => {
      showNotif(`⚠️ ${data.message}`);
    });

    return () => {
      socket.off('connect_error');
      socket.off('disconnect');
      socket.off('game_started');
      socket.off('dice_rolled');
      socket.off('piece_moved');
      socket.off('game_state_update');
      socket.off('game_over');
      socket.off('player_joined');
      socket.off('player_left');
      socket.off('message_received');
      socket.off('lobby_reset');
      socket.off('room_rejoined');
      socket.off('error');
    };
  }, [myPlayerId, showNotif, player]);

  const handleStartGame = () => {
    socket.emit('start_game', { roomCode });
  };

  const handleRollDice = () => {
    socket.emit('roll_dice', { roomCode });
  };

  const handlePieceClick = (pieceId) => {
    if (!gameState?.diceRolled) return;
    socket.emit('move_piece', { roomCode, pieceId });
  };

  const handleSendMessage = (message) => {
    socket.emit('send_message', { roomCode, message });
  };

  const handlePlayAgain = () => {
    socket.emit('play_again', { roomCode });
  };

  const handleLeave = () => {
    socket.emit('leave_room', { roomCode, playerId: myPlayerId });
    navigate('lobby');
  };

  const currentPlayer = gameState?.players[gameState.currentTurnIndex];
  const isMyTurn = currentPlayer?.id === myPlayerId;
  // validMoves is only relevant for Ludo
  const validMoves = (!isSnakeLadder && isMyTurn) ? (gameState?.validMoves || []) : [];

  // Lobby view (waiting for game to start)
  if (!gameState) {
    return (
      <div className={styles.page}>
        <div className={styles.lobby}>
          <div className={styles.lobbyHeader}>
            <button className={styles.leaveBtn} onClick={handleLeave}>← Leave</button>
            <h2 className={styles.lobbyTitle}>Waiting Room</h2>
            <div className={styles.roomCode}>
              <span className={styles.roomCodeLabel}>Room Code</span>
              <span className={styles.roomCodeValue}>{roomCode}</span>
            </div>
          </div>

          {/* Game type badge */}
          <div className={styles.gameTypeBadge}>
            {GAME_TYPE_LABELS[gameType] || gameType}
          </div>

          <div className={styles.waitingPlayers}>
            <div className={styles.sectionLabel}>Players ({players.length}/{room?.maxPlayers || 4})</div>
            {players.map(p => (
              <div key={p.id} className={styles.waitingPlayer} style={{ '--color': COLOR_HEX[p.color] }}>
                {p.avatar
                  ? <span className={styles.waitingAvatar}>{p.avatar}</span>
                  : <div className={styles.waitingColorDot} style={{ background: COLOR_HEX[p.color] }} />}
                <span className={styles.waitingPlayerName}>{p.name}</span>
                {p.isHost && <span className={styles.hostBadge}>Host</span>}
                {p.id === myPlayerId && <span className={styles.youBadge2}>You</span>}
              </div>
            ))}
            {Array.from({ length: Math.max(0, (room?.maxPlayers || 4) - players.length) }).map((_, i) => (
              <div key={`empty-${i}`} className={styles.emptySlot}>
                Waiting for player…
              </div>
            ))}
          </div>

          <div className={styles.shareBox}>
            <p className={styles.shareText}>Share this code with friends:</p>
            <div className={styles.shareCode}>{roomCode}</div>
          </div>

          {isHost ? (
            <button
              className={`btn btn-primary ${styles.startBtn}`}
              disabled={players.length < 2}
              onClick={handleStartGame}
            >
              {players.length < 2 ? 'Waiting for players…' : '🎮 Start Game'}
            </button>
          ) : (
            <div className={styles.waitingMsg}>
              Waiting for the host to start the game…
            </div>
          )}

          {/* Chat in lobby too */}
          <Chat
            messages={messages}
            onSendMessage={handleSendMessage}
            myPlayerId={myPlayerId}
            players={players}
          />
        </div>
      </div>
    );
  }

  // Main game view
  return (
    <div className={styles.page}>
      {/* Notification toast */}
      {notification && (
        <div className={styles.notif}>{notification}</div>
      )}

      {/* Header */}
      <div className={styles.gameHeader}>
        <button className={styles.leaveBtn} onClick={handleLeave}>← Leave</button>
        <div className={styles.headerCenter}>
          <span className={styles.roomCodeSmall}>{roomCode}</span>
          <span className={styles.gameTypePill}>{GAME_TYPE_LABELS[gameType]}</span>
          <span className={styles.turnInfo}>
            {isMyTurn ? (
              <span className={styles.myTurnBadge}>Your Turn</span>
            ) : (
              <span className={styles.waitingTurnBadge}>
                {currentPlayer?.name}'s turn
              </span>
            )}
          </span>
        </div>
        <div className={styles.headerRight} />
      </div>

      <div className={styles.gameLayout}>
        {/* Board — branches by gameType */}
        <div className={styles.boardArea}>
          {isSnakeLadder ? (
            <SnakeLadderBoard
              gameState={gameState}
              myPlayerId={myPlayerId}
            />
          ) : (
            <Board
              gameState={gameState}
              currentPlayer={currentPlayer}
              validMoves={validMoves}
              onPieceClick={handlePieceClick}
              myPlayerId={myPlayerId}
            />
          )}
        </div>

        {/* Right panel — all components are now game-type-aware via the gameType prop */}
        <div className={styles.sidePanel}>
          <PlayerPanel
            gameState={gameState}
            players={gameState.players}
            roomPlayers={players}
            myPlayerId={myPlayerId}
            gameType={gameType}
          />

          <DiceRoller
            onRoll={handleRollDice}
            disabled={!isMyTurn || gameState.diceRolled}
            diceResult={gameState.diceResult}
            isMyTurn={isMyTurn}
            gameState={gameState}
            gameType={gameType}
          />

          <Chat
            messages={messages}
            onSendMessage={handleSendMessage}
            myPlayerId={myPlayerId}
            players={players}
          />
        </div>
      </div>

      {/* Game Over Modal */}
      {gameOver && (
        <GameOver
          winners={gameOver.winners}
          gameState={gameOver.gameState || gameState}
          onPlayAgain={handlePlayAgain}
          onHome={handleLeave}
          isHost={isHost}
          gameType={gameType}
        />
      )}
    </div>
  );
}


// components/Chat.jsx
import React, { useState, useEffect, useRef } from 'react';
import styles from './Chat.module.css';
import { COLOR_HEX } from '../utils/boardLayout';

export default function Chat({ messages = [], onSendMessage, myPlayerId, players = [] }) {
  const [input, setInput] = useState('');
  const bottomRef = useRef(null);
  const listRef = useRef(null);

  // Auto scroll on new messages
  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSend = () => {
    const msg = input.trim();
    if (!msg) return;
    onSendMessage(msg);
    setInput('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const getPlayerInfo = (playerName) => {
    const p = players.find(pl => pl.name === playerName);
    return {
      color: p ? COLOR_HEX[p.color] || '#94A3B8' : '#94A3B8',
      avatar: p?.avatar || null,
    };
  };

  const formatTime = (ts) => {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className={styles.chat}>
      <div className={styles.header}>
        <span className={styles.headerTitle}>Chat</span>
        <span className={styles.msgCount}>{messages.length}</span>
      </div>

      <div className={styles.messages} ref={listRef}>
        {messages.length === 0 && (
          <div className={styles.empty}>No messages yet. Say hi! 👋</div>
        )}
        {messages.map((msg, i) => (
          <div
            key={msg.id || i}
            className={`${styles.message} ${msg.type === 'system' ? styles.systemMsg : ''}`}
          >
            {msg.type === 'system' ? (
              <span className={styles.systemText}>{msg.message}</span>
            ) : (
              <>
                {(() => { const info = getPlayerInfo(msg.playerName); return (
                  <span
                    className={styles.sender}
                    style={{ color: info.color }}
                  >
                    {info.avatar && <span className={styles.chatAvatar}>{info.avatar}</span>}
                    {msg.playerName}
                  </span>
                ); })()}
                <span className={styles.msgText}>{msg.message}</span>
                <span className={styles.timestamp}>{formatTime(msg.timestamp)}</span>
              </>
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <div className={styles.inputRow}>
        <input
          className={styles.chatInput}
          placeholder="Type a message…"
          value={input}
          maxLength={200}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
        />
        <button
          className={styles.sendBtn}
          onClick={handleSend}
          disabled={!input.trim()}
        >
          ↑
        </button>
      </div>
    </div>
  );
}

// components/DiceRoller.jsx
import React, { useState, useEffect } from 'react';
import styles from './DiceRoller.module.css';

const DICE_FACES = {
  1: [false, false, false, false, true,  false, false, false, false],
  2: [true,  false, false, false, false, false, false, false, true],
  3: [true,  false, false, false, true,  false, false, false, true],
  4: [true,  false, true,  false, false, false, true,  false, true],
  5: [true,  false, true,  false, true,  false, true,  false, true],
  6: [true,  false, true,  true,  false, true,  true,  false, true],
};

// D3: Sound effect stubs — call playSound('dice'|'capture'|'win') wherever needed.
// Wire these up by replacing the console.log with new Audio(url).play() later.
export function playSound(name) {
  // TODO (D3): replace with actual audio assets when available
  // e.g. new Audio('/sounds/dice.mp3').play().catch(() => {});
}

export default function DiceRoller({ onRoll, disabled, diceResult, isMyTurn, gameState, gameType }) {
  const [rolling, setRolling] = useState(false);
  const [displayResult, setDisplayResult] = useState(null);
  const [rollingNum, setRollingNum] = useState(1);
  const isSnakeLadder = gameType === 'snake-ladder';

  useEffect(() => {
    if (diceResult) {
      setDisplayResult(diceResult);
      setRolling(false);
    }
  }, [diceResult]);

  // Animate rolling
  useEffect(() => {
    if (!rolling) return;
    const interval = setInterval(() => {
      setRollingNum(Math.floor(Math.random() * 6) + 1);
    }, 80);
    return () => clearInterval(interval);
  }, [rolling]);

  const handleRoll = () => {
    if (disabled || rolling) return;
    setRolling(true);
    setDisplayResult(null);
    playSound('dice');
    setTimeout(() => {
      onRoll();
    }, 400);
  };

  const canRoll = isMyTurn && !disabled && !rolling && !gameState?.diceRolled;
  // S&L auto-moves, so there is no "pick a piece" step
  const mustPick = !isSnakeLadder && isMyTurn && gameState?.diceRolled && gameState?.validMoves?.length > 0;

  const showNum = rolling ? rollingNum : (displayResult || 1);
  const dots = DICE_FACES[showNum] || DICE_FACES[1];

  return (
    <div className={styles.container}>
      <div className={styles.statusLabel}>
        {!isMyTurn ? "Waiting for opponent…" :
         mustPick ? "Choose a piece to move" :
         canRoll ? "Your turn — roll the dice!" :
         rolling ? "Rolling…" : ""}
      </div>

      {/* Dice visual */}
      <button
        className={`${styles.dice} ${rolling ? styles.rolling : ''} ${canRoll ? styles.canRoll : ''}`}
        onClick={handleRoll}
        disabled={!canRoll}
        aria-label={`Roll dice${displayResult ? `, last result: ${displayResult}` : ''}`}
      >
        <div className={styles.diceInner}>
          {dots.map((hasDot, i) => (
            <div key={i} className={`${styles.dot} ${hasDot ? styles.dotVisible : ''}`} />
          ))}
        </div>
        {canRoll && <div className={styles.rollHint}>ROLL</div>}
      </button>

      {displayResult && (
        <div className={`${styles.result} ${displayResult === 6 ? styles.bonusResult : ''}`}>
          {displayResult === 6 ? '🎉 Six! Roll again!' : `Rolled a ${displayResult}`}
        </div>
      )}
    </div>
  );
}

// components/SnakeLadderBoard.jsx
import React, { useMemo } from 'react';
import styles from './SnakeLadderBoard.module.css';
import {
  LADDERS,
  SNAKES,
  GRID_DIMENSION,
  cellToGridPosition,
} from '../utils/snakeLadderLayout';
import { COLOR_HEX } from '../utils/boardLayout';

const CELL_PX = 56;
const BOARD_PX = GRID_DIMENSION * CELL_PX; // 560px

// Pre-compute which cells have snakes/ladders for quick lookup
const SNAKE_HEADS = new Set(Object.keys(SNAKES).map(Number));
const LADDER_BOTTOMS = new Set(Object.keys(LADDERS).map(Number));

function cellCenter(cellNumber) {
  const { row, col } = cellToGridPosition(cellNumber);
  return {
    x: col * CELL_PX + CELL_PX / 2,
    y: row * CELL_PX + CELL_PX / 2,
  };
}

export default function SnakeLadderBoard({ gameState, myPlayerId }) {
  // Build a map of cell -> players currently on it
  const cellPlayers = useMemo(() => {
    const map = {};
    if (!gameState) return map;
    for (const player of gameState.players) {
      if (player.position > 0 && !player.finished) {
        const cell = player.position;
        if (!map[cell]) map[cell] = [];
        map[cell].push(player);
      }
    }
    return map;
  }, [gameState]);

  // Render the 100 cells
  const cells = useMemo(() => {
    const out = [];
    for (let cellNum = 1; cellNum <= 100; cellNum++) {
      const { row, col } = cellToGridPosition(cellNum);
      const isSnakeHead = SNAKE_HEADS.has(cellNum);
      const isLadderBottom = LADDER_BOTTOMS.has(cellNum);
      const playersHere = cellPlayers[cellNum] || [];

      out.push({ cellNum, row, col, isSnakeHead, isLadderBottom, playersHere });
    }
    return out;
  }, [cellPlayers]);

  return (
    <div className={styles.boardWrapper}>
      <div className={styles.board} style={{ width: BOARD_PX, height: BOARD_PX }}>

        {/* ── Cell backgrounds + numbers ─────────────────────────── */}
        {cells.map(({ cellNum, row, col, isSnakeHead, isLadderBottom, playersHere }) => (
          <div
            key={cellNum}
            className={`${styles.cell}
              ${isSnakeHead ? styles.snakeCell : ''}
              ${isLadderBottom ? styles.ladderCell : ''}
              ${cellNum === 100 ? styles.winCell : ''}`}
            style={{
              left: col * CELL_PX,
              top: row * CELL_PX,
              width: CELL_PX,
              height: CELL_PX,
            }}
          >
            <span className={styles.cellNum}>{cellNum}</span>

            {/* Icons for snake/ladder cells */}
            {isSnakeHead && <span className={styles.cellIcon}>🐍</span>}
            {isLadderBottom && <span className={styles.cellIcon}>🪜</span>}
            {cellNum === 100 && <span className={styles.cellIcon}>🏆</span>}

            {/* Player tokens */}
            {playersHere.length > 0 && (
              <div className={styles.tokens}>
                {playersHere.map((player, i) => (
                  <div
                    key={player.id}
                    className={`${styles.token} ${player.id === myPlayerId ? styles.myToken : ''}`}
                    style={{
                      background: COLOR_HEX[player.color] || player.colorHex || '#94A3B8',
                      transform: playersHere.length > 1
                        ? `translate(${(i - (playersHere.length - 1) / 2) * 14}px, 0)`
                        : 'none',
                      boxShadow: player.id === myPlayerId
                        ? `0 0 10px ${COLOR_HEX[player.color]}` : 'none',
                    }}
                    title={player.name}
                  />
                ))}
              </div>
            )}
          </div>
        ))}

        {/* ── SVG overlay: snake and ladder lines ────────────────── */}
        <svg
          className={styles.svgOverlay}
          width={BOARD_PX}
          height={BOARD_PX}
          viewBox={`0 0 ${BOARD_PX} ${BOARD_PX}`}
          xmlns="http://www.w3.org/2000/svg"
          style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}
        >
          <defs>
            <marker id="arrowRed" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
              <path d="M0,0 L6,3 L0,6 Z" fill="#EF4444" opacity="0.85" />
            </marker>
            <marker id="arrowGreen" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
              <path d="M0,0 L6,3 L0,6 Z" fill="#22C55E" opacity="0.85" />
            </marker>
          </defs>

          {/* Snakes: head → tail (red, going downward) */}
          {Object.entries(SNAKES).map(([head, tail]) => {
            const h = cellCenter(Number(head));
            const t = cellCenter(Number(tail));
            // Gentle S-curve control points
            const cx1 = h.x + (t.x - h.x) * 0.25 + 20;
            const cy1 = h.y + (t.y - h.y) * 0.1;
            const cx2 = t.x - (t.x - h.x) * 0.25 - 20;
            const cy2 = h.y + (t.y - h.y) * 0.9;
            return (
              <path
                key={`snake-${head}`}
                d={`M${h.x},${h.y} C${cx1},${cy1} ${cx2},${cy2} ${t.x},${t.y}`}
                stroke="#EF4444"
                strokeWidth="3"
                strokeOpacity="0.75"
                fill="none"
                strokeDasharray="6 3"
                markerEnd="url(#arrowRed)"
              />
            );
          })}

          {/* Ladders: bottom → top (green, going upward) */}
          {Object.entries(LADDERS).map(([bottom, top]) => {
            const b = cellCenter(Number(bottom));
            const t = cellCenter(Number(top));
            return (
              <line
                key={`ladder-${bottom}`}
                x1={b.x} y1={b.y}
                x2={t.x} y2={t.y}
                stroke="#22C55E"
                strokeWidth="3.5"
                strokeOpacity="0.72"
                markerEnd="url(#arrowGreen)"
              />
            );
          })}
        </svg>
      </div>
    </div>
  );
}

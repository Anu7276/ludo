// components/Board.jsx — Main Ludo Board (4-player and 6-player)
import React, { useMemo } from 'react';
import styles from './Board.module.css';
import {
  // 4-player
  LUDO_PATH,
  HOME_COLUMNS,
  HOME_BASES,
  HOME_PAWN_POSITIONS,
  CENTER_CELL,
  SAFE_POSITIONS,
  PLAYER_START_POSITIONS,
  getPlayerPieceCell,
  // 6-player
  LUDO_PATH_6P,
  HOME_COLUMNS_6P,
  HOME_BASES_6P,
  HOME_PAWN_POSITIONS_6P,
  CENTER_CELL_6P,
  SAFE_POSITIONS_6P,
  PLAYER_START_POSITIONS_6P,
  getPlayerPieceCell6P,
  // shared
  COLOR_HEX,
  COLOR_LIGHT,
} from '../utils/boardLayout';

const PLAYER_COLORS_ARR = ['red', 'yellow', 'green', 'blue', 'purple', 'cyan'];

// ─── 4-player board constants ─────────────────────────────────────────────────
const GRID_4P = 15;
const CELL_4P = 44; // px per cell

// ─── 6-player board constants ─────────────────────────────────────────────────
const GRID_6P = 21;
const CELL_6P = 32; // px per cell (smaller to keep board manageable)

// Build home-col color maps for both modes
const HOME_COL_COLOR_4P = {};
for (let i = 0; i < 4; i++) {
  for (const [r, c] of HOME_COLUMNS[i]) {
    HOME_COL_COLOR_4P[`${r},${c}`] = PLAYER_COLORS_ARR[i];
  }
}

const HOME_COL_COLOR_6P = {};
for (let i = 0; i < 6; i++) {
  for (const [r, c] of HOME_COLUMNS_6P[i]) {
    HOME_COL_COLOR_6P[`${r},${c}`] = PLAYER_COLORS_ARR[i];
  }
}

function cellKey(r, c) { return `${r},${c}`; }

export default function Board({ gameState, currentPlayer, validMoves = [], onPieceClick, myPlayerId }) {
  const playerCount = gameState?.playerCount ?? gameState?.players?.length ?? 4;
  const is6P = playerCount >= 5;

  // Select board constants
  const GRID = is6P ? GRID_6P : GRID_4P;
  const CELL = is6P ? CELL_6P : CELL_4P;
  const BOARD_PX = GRID * CELL;
  const PATH = is6P ? LUDO_PATH_6P : LUDO_PATH;
  const HOME_COL_COLOR = is6P ? HOME_COL_COLOR_6P : HOME_COL_COLOR_4P;
  const HOME_BASES_MAP = is6P ? HOME_BASES_6P : HOME_BASES;
  const HOME_PAWN_POS = is6P ? HOME_PAWN_POSITIONS_6P : HOME_PAWN_POSITIONS;
  const CENTER = is6P ? CENTER_CELL_6P : CENTER_CELL;
  const SAFE_POS = is6P ? SAFE_POSITIONS_6P : SAFE_POSITIONS;
  const START_POS = is6P ? PLAYER_START_POSITIONS_6P : PLAYER_START_POSITIONS;
  const getPieceCell = is6P ? getPlayerPieceCell6P : getPlayerPieceCell;
  const numPlayers = is6P ? Math.min(playerCount, 6) : 4;

  // Build grid: what's in each cell
  const cellData = useMemo(() => {
    const data = {};
    if (!gameState) return data;

    for (const player of gameState.players) {
      const pIdx = player.index;
      const color = player.color;
      for (const piece of player.pieces) {
        if (piece.finished) continue;
        const cell = getPieceCell(pIdx, piece.relativePos);
        if (!cell) continue;
        const key = cellKey(cell[0], cell[1]);
        if (!data[key]) data[key] = [];
        data[key].push({ playerId: player.id, pieceId: piece.id, color, relPos: piece.relativePos });
      }
    }
    return data;
  }, [gameState, getPieceCell]);

  // Valid move targets (absolute board cells)
  const validTargetCells = useMemo(() => {
    if (!validMoves?.length) return new Set();
    const targets = new Set();
    validMoves.forEach(m => {
      const pIdx = gameState?.players.findIndex(p => p.id === myPlayerId);
      if (pIdx === -1 || pIdx === undefined) return;
      const cell = getPieceCell(pIdx, m.newRelPos);
      if (cell) targets.add(cellKey(cell[0], cell[1]));
    });
    return targets;
  }, [validMoves, gameState, myPlayerId, getPieceCell]);

  // Valid moveable pieces
  const validPieceIds = useMemo(() => {
    return new Set(validMoves.map(m => `${myPlayerId}_${m.pieceId}`));
  }, [validMoves, myPlayerId]);

  // Path cell set
  const pathCellSet = useMemo(() => {
    const s = new Set();
    PATH.forEach(([r, c]) => s.add(cellKey(r, c)));
    return s;
  }, [PATH]);

  // Determine cell background color
  function getCellBg(r, c) {
    const key = cellKey(r, c);
    if (r === CENTER[0] && c === CENTER[1]) return '#1A1A2E';

    const hcColor = HOME_COL_COLOR[key];
    if (hcColor) return COLOR_LIGHT[hcColor] + '55';

    if (!is6P) {
      if (r <= 5 && c <= 5) return COLOR_HEX.red + '22';
      if (r <= 5 && c >= 9) return COLOR_HEX.yellow + '22';
      if (r >= 9 && c >= 9) return COLOR_HEX.green + '22';
      if (r >= 9 && c <= 5) return COLOR_HEX.blue + '22';
    } else {
      if (r <= 5 && c <= 5) return COLOR_HEX.red + '22';
      if (r <= 5 && c >= 8 && c <= 13) return COLOR_HEX.yellow + '22';
      if (r <= 5 && c >= 15) return COLOR_HEX.green + '22';
      if (r >= 15 && c >= 15) return COLOR_HEX.blue + '22';
      if (r >= 15 && c >= 8 && c <= 13) return COLOR_HEX.purple + '22';
      if (r >= 15 && c <= 5) return COLOR_HEX.cyan + '22';
    }
    return 'transparent';
  }

  function getCellBorder(r, c) {
    const key = cellKey(r, c);
    if (HOME_COL_COLOR[key]) {
      return `1px solid ${COLOR_HEX[HOME_COL_COLOR[key]]}44`;
    }
    return '1px solid #2D2D4A44';
  }

  function isSafe(r, c) {
    const absPos = PATH.findIndex(([pr, pc]) => pr === r && pc === c);
    return absPos >= 0 && SAFE_POS.has(absPos);
  }

  function getStartColor(r, c) {
    const absPos = PATH.findIndex(([pr, pc]) => pr === r && pc === c);
    if (absPos < 0) return null;
    const idx = START_POS.indexOf(absPos);
    if (idx >= 0) return PLAYER_COLORS_ARR[idx];
    return null;
  }

  function handlePieceClick(e, playerId, pieceId) {
    e.stopPropagation();
    const pieceKey = `${playerId}_${pieceId}`;
    if (validPieceIds.has(pieceKey)) {
      onPieceClick && onPieceClick(pieceId);
    }
  }

  function getHomePieces(playerIndex) {
    if (!gameState) return [];
    const player = gameState.players[playerIndex];
    if (!player) return [];
    return player.pieces.filter(p => p.relativePos === -1 && !p.finished);
  }

  return (
    <div className={styles.boardWrapper}>
      <div
        className={styles.board}
        style={{ width: BOARD_PX, height: BOARD_PX }}
      >
        {/* Grid cells */}
        {Array.from({ length: GRID }, (_, r) =>
          Array.from({ length: GRID }, (_, c) => {
            const key = cellKey(r, c);
            const isPath = pathCellSet.has(key);
            const safe = isSafe(r, c);
            const startColor = getStartColor(r, c);
            const isValidTarget = validTargetCells.has(key);
            const isCenter = r === CENTER[0] && c === CENTER[1];
            const homeColColor = HOME_COL_COLOR[key];
            const pieces = cellData[key] || [];

            return (
              <div
                key={key}
                className={`${styles.cell} ${isPath ? styles.pathCell : ''} ${safe ? styles.safeCell : ''} ${isValidTarget ? styles.validTarget : ''}`}
                style={{
                  left: c * CELL,
                  top: r * CELL,
                  width: CELL,
                  height: CELL,
                  background: isValidTarget ? 'rgba(34,197,94,0.25)' : getCellBg(r, c),
                  border: getCellBorder(r, c),
                }}
              >
                {/* Home column color strip */}
                {homeColColor && !isValidTarget && (
                  <div
                    className={styles.homeColStrip}
                    style={{ background: COLOR_HEX[homeColColor] + '33', border: `1px solid ${COLOR_HEX[homeColColor]}55` }}
                  />
                )}

                {/* Safe star */}
                {safe && !startColor && <span className={is6P ? styles.starIconSm : styles.starIcon}>⭐</span>}

                {/* Start cell colored dot */}
                {startColor && (
                  <div
                    className={styles.startDot}
                    style={{ background: COLOR_HEX[startColor] + '44', border: `2px solid ${COLOR_HEX[startColor]}88` }}
                  />
                )}

                {/* Valid target highlight */}
                {isValidTarget && <div className={styles.validGlow} />}

                {/* Center */}
                {isCenter && (
                  <div className={is6P ? styles.centerStarSm : styles.centerStar}>★</div>
                )}

                {/* Pieces on this cell */}
                {pieces.length > 0 && (
                  <div className={styles.piecesContainer}>
                    {pieces.map((p, i) => {
                      const pieceKey = `${p.playerId}_${p.pieceId}`;
                      const isMovable = validPieceIds.has(pieceKey);
                      return (
                        <div
                          key={i}
                          className={`${styles.piece} ${is6P ? styles.pieceSm : ''} ${isMovable ? styles.movablePiece : ''}`}
                          style={{
                            background: COLOR_HEX[p.color] || p.color,
                            transform: pieces.length > 1
                              ? `translate(${(i - (pieces.length - 1) / 2) * (is6P ? 8 : 12)}px, 0)`
                              : 'none',
                            zIndex: isMovable ? 10 : 5,
                            boxShadow: isMovable ? `0 0 12px ${COLOR_HEX[p.color]}` : 'none',
                          }}
                          onClick={(e) => handlePieceClick(e, p.playerId, p.pieceId)}
                          title={`Piece ${p.pieceId + 1}`}
                        >
                          {p.pieceId + 1}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })
        )}

        {/* Home base areas */}
        {Array.from({ length: numPlayers }, (_, pIdx) => {
          const base = HOME_BASES_MAP[pIdx];
          if (!base) return null;
          const [r1, r2] = base.rows;
          const [c1, c2] = base.cols;
          const color = PLAYER_COLORS_ARR[pIdx];
          const homePieces = getHomePieces(pIdx);
          const spawnPos = HOME_PAWN_POS[pIdx] || [];
          const player = gameState?.players[pIdx];

          return (
            <div
              key={`home-${pIdx}`}
              className={styles.homeBase}
              style={{
                left: c1 * CELL + 2,
                top: r1 * CELL + 2,
                width: (c2 - c1 + 1) * CELL - 4,
                height: (r2 - r1 + 1) * CELL - 4,
                background: `${COLOR_HEX[color]}18`,
                border: `2px solid ${COLOR_HEX[color]}55`,
              }}
            >
              {/* Player name label */}
              {player && (
                <div className={styles.homeLabel} style={{ color: COLOR_HEX[color] }}>
                  {player.name}
                </div>
              )}
              {/* Inner colored circle */}
              <div
                className={styles.homeInner}
                style={{ background: COLOR_HEX[color] + '22', border: `2px solid ${COLOR_HEX[color]}44` }}
              />
              {/* Home pieces */}
              {homePieces.map((piece) => {
                const pos = spawnPos[piece.id];
                if (!pos) return null;
                const absX = (pos[1] - c1) * CELL;
                const absY = (pos[0] - r1) * CELL;
                const pieceKey = `${player?.id}_${piece.id}`;
                const isMovable = validPieceIds.has(pieceKey);
                return (
                  <div
                    key={piece.id}
                    className={`${styles.homePiece} ${is6P ? styles.homePieceSm : ''} ${isMovable ? styles.movablePiece : ''}`}
                    style={{
                      left: absX + CELL / 2 - (is6P ? 10 : 14),
                      top: absY + CELL / 2 - (is6P ? 10 : 14),
                      background: COLOR_HEX[color],
                      boxShadow: isMovable ? `0 0 16px ${COLOR_HEX[color]}` : 'none',
                    }}
                    onClick={() => isMovable && onPieceClick && onPieceClick(piece.id)}
                    title={`Piece ${piece.id + 1}`}
                  >
                    {piece.id + 1}
                  </div>
                );
              })}
            </div>
          );
        })}

        {/* Finish area in center */}
        <div
          className={styles.centerFinish}
          style={{
            left: is6P ? CENTER[1] * CELL - CELL : 5 * CELL + 2,
            top: is6P ? CENTER[0] * CELL - CELL : 5 * CELL + 2,
            width: is6P ? CELL * 3 - 4 : CELL * 5 - 4,
            height: is6P ? CELL * 3 - 4 : CELL * 5 - 4,
          }}
        >
          <div className={styles.finishTriangles}>
            {PLAYER_COLORS_ARR.slice(0, numPlayers).map((c, i) => (
              <div
                key={c}
                className={styles.finishTriangle}
                style={{
                  background: `linear-gradient(${i * (360 / numPlayers)}deg, ${COLOR_HEX[c]}88, transparent)`,
                  transform: `rotate(${i * (360 / numPlayers)}deg)`,
                }}
              />
            ))}
          </div>
          <div className={is6P ? styles.finishStarSm : styles.finishStar}>🏆</div>
        </div>
      </div>
    </div>
  );
}

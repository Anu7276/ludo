// components/PlayerPanel.jsx
import React from 'react';
import styles from './PlayerPanel.module.css';
import { COLOR_HEX } from '../utils/boardLayout';

export default function PlayerPanel({ gameState, players, roomPlayers, myPlayerId, gameType }) {
  if (!gameState || !players) return null;

  const currentPlayer = gameState.players[gameState.currentTurnIndex];
  const isSnakeLadder = gameType === 'snake-ladder';

  return (
    <div className={styles.panel}>
      <div className={styles.sectionTitle}>Players</div>
      <div className={styles.playerList}>
        {gameState.players.map((player) => {
          const isCurrentTurn = player.id === currentPlayer?.id;
          const isMe = player.id === myPlayerId;
          const colorHex = COLOR_HEX[player.color] || '#94A3B8';

          // Derive finished state + stats depending on game type
          const isFinished = isSnakeLadder
            ? player.finished === true
            : player.piecesFinished === 4;

          const rank = isSnakeLadder
            ? (gameState.winners?.indexOf(player.id) >= 0 ? gameState.winners.indexOf(player.id) + 1 : null)
            : player.rank;

          return (
            <div
              key={player.id}
              className={`${styles.playerItem} ${isCurrentTurn ? styles.currentTurn : ''} ${isFinished ? styles.finished : ''}`}
              style={{ '--player-color': colorHex }}
            >
              <div className={styles.colorBar} style={{ background: colorHex }} />

              <div className={styles.playerInfo}>
                <div className={styles.playerNameRow}>
                  {player.avatar && <span className={styles.avatar}>{player.avatar}</span>}
                  <span className={styles.playerName}>{player.name}</span>
                  {isMe && <span className={styles.youBadge}>You</span>}
                  {isFinished && rank && (
                    <span className={styles.rankBadge}>
                      {rank === 1 ? '🥇' : rank === 2 ? '🥈' : rank === 3 ? '🥉' : `#${rank}`}
                    </span>
                  )}
                </div>

                {isSnakeLadder ? (
                  // Snake & Ladder: show current board position
                  <div className={styles.piecesRow}>
                    <div className={styles.piecesStat} title="Current position">
                      📍 {player.position === 0 ? 'Start' : player.position === 100 ? '100 🏆' : `Cell ${player.position}`}
                    </div>
                  </div>
                ) : (
                  // Ludo: show pieces breakdown
                  <div className={styles.piecesRow}>
                    <div className={styles.piecesStat} title="In home base">
                      🏠 {player.pieces.filter(p => p.relativePos === -1 && !p.finished).length}
                    </div>
                    <div className={styles.piecesStat} title="On board">
                      🎯 {player.pieces.filter(p => p.relativePos >= 0 && !p.finished).length}
                    </div>
                    <div className={styles.piecesStat} title="Finished">
                      ✅ {player.piecesFinished}
                    </div>
                  </div>
                )}
              </div>

              {isCurrentTurn && !isFinished && (
                <div className={styles.turnIndicator}>
                  <div className={styles.turnDot} />
                  {isMe ? 'Your turn!' : `${player.name}'s turn`}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Dice result display */}
      {gameState.diceResult && (
        <div className={styles.lastRoll}>
          <span className={styles.lastRollLabel}>Last roll</span>
          <div className={styles.diceDisplay}>
            {getDiceFace(gameState.diceResult)}
          </div>
          <span className={styles.lastRollNum}>{gameState.diceResult}</span>
        </div>
      )}
    </div>
  );
}

function getDiceFace(n) {
  const faces = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
  return faces[n] || '🎲';
}

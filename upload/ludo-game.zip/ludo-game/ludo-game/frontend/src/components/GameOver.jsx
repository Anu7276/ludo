// components/GameOver.jsx
import React from 'react';
import styles from './GameOver.module.css';
import { COLOR_HEX } from '../utils/boardLayout';

export default function GameOver({ winners, gameState, onPlayAgain, onHome, isHost, gameType }) {
  const isSnakeLadder = gameType === 'snake-ladder';

  const sortedPlayers = [...(gameState?.players || [])].sort((a, b) => {
    if (isSnakeLadder) {
      // Sort by order in the winners array (finish order), unfinished last
      const ai = gameState.winners?.indexOf(a.id) ?? -1;
      const bi = gameState.winners?.indexOf(b.id) ?? -1;
      if (ai >= 0 && bi >= 0) return ai - bi;
      if (ai >= 0) return -1;
      if (bi >= 0) return 1;
      return b.position - a.position; // unfinished: higher position = better
    }
    // Ludo sort
    if (a.rank && b.rank) return a.rank - b.rank;
    if (a.rank) return -1;
    if (b.rank) return 1;
    return b.piecesFinished - a.piecesFinished;
  });

  const rankEmoji = (rank) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return `#${rank}`;
  };

  const winner = sortedPlayers[0];

  return (
    <div className={styles.overlay}>
      <div className={styles.modal}>
        <div className={styles.confetti} aria-hidden="true">
          {Array.from({length: 20}).map((_, i) => (
            <div key={i} className={styles.confettiPiece} style={{
              left: `${Math.random()*100}%`,
              background: Object.values(COLOR_HEX)[Math.floor(Math.random()*4)],
              animationDelay: `${Math.random()*2}s`,
              animationDuration: `${1.5 + Math.random()}s`,
            }} />
          ))}
        </div>

        <div className={styles.trophy}>🏆</div>

        <h2 className={styles.title}>Game Over!</h2>
        {winner && (
          <p className={styles.winnerText} style={{ color: COLOR_HEX[winner.color] }}>
            {winner.avatar && <span>{winner.avatar} </span>}
            {winner.name} wins!
          </p>
        )}

        <div className={styles.rankings}>
          <div className={styles.rankingsTitle}>Final Rankings</div>
          {sortedPlayers.map((player, i) => {
            const rank = isSnakeLadder
              ? (gameState.winners?.indexOf(player.id) >= 0 ? gameState.winners.indexOf(player.id) + 1 : i + 1)
              : (player.rank || i + 1);
            const statLabel = isSnakeLadder
              ? `Cell ${player.position}/100`
              : `${player.piecesFinished}/4 pieces`;

            return (
              <div
                key={player.id}
                className={styles.rankRow}
                style={{ '--color': COLOR_HEX[player.color] }}
              >
                <span className={styles.rankEmoji}>{rankEmoji(rank)}</span>
                {player.avatar
                  ? <span className={styles.avatarSmall}>{player.avatar}</span>
                  : <div className={styles.colorDot} style={{ background: COLOR_HEX[player.color] }} />
                }
                <span className={styles.playerName}>{player.name}</span>
                <span className={styles.piecesInfo}>{statLabel}</span>
              </div>
            );
          })}
        </div>

        <div className={styles.actions}>
          {isHost && (
            <button className={`btn btn-primary ${styles.actionBtn}`} onClick={onPlayAgain}>
              🔄 Play Again
            </button>
          )}
          {!isHost && (
            <p className={styles.waitingText}>Waiting for host to restart…</p>
          )}
          <button className={`btn btn-ghost ${styles.actionBtn}`} onClick={onHome}>
            🏠 Leave
          </button>
        </div>
      </div>
    </div>
  );
}
